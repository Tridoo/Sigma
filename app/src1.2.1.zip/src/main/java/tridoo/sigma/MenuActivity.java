package tridoo.sigma;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.Date;


public class MenuActivity extends Activity {
    DAO dao;
    String nick,email;
    boolean isUpdateNick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        setNick();
        setLogoSize6();
        setButtons();

        //showAds();
    }


    private void setButtons() {
        setHelpButton();
        setSaveButton();
        setSize5Buttons();
        setSize6Buttons();
    }

    private void setSize6Buttons() {
        for (int id : Maps.buttonsSize6) {
            findViewById(id).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isUsableSize6()) {
                        startActivity(view);
                    } else {
                        showLocked6();
                    }
                }
            });
        }
    }

    private void setSize5Buttons() {
        for(int id: Maps.buttonsSize5){
            findViewById(id).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(view);
                }
            });
        }
    }

    private void setLogoSize6(){
        int idLogo6 = !isUsableSize6() ? R.mipmap.logo6_off : R.mipmap.logo6;
        ((ImageView) findViewById(R.id.ivLogo6)).setImageDrawable(getResources().getDrawable(idLogo6));
    }

    private void setSaveButton() {
        final ImageView btnSave=(ImageView)findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateNick();
            }
        });

        TextWatcher watcher= new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {            }
            public void onTextChanged(CharSequence s, int start, int before, int count) {            }
            @Override
            public void afterTextChanged(Editable s) {
                btnSave.setImageDrawable(getResources().getDrawable(R.mipmap.save));
            }
        };
        ((EditText)findViewById(R.id.eName)).addTextChangedListener(watcher);
    }

    private void setHelpButton() {
        findViewById(R.id.btnHelp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(view);
            }
        });
    }


    private void startActivity(View button) {
        int id = button.getId();
        Intent intent = new Intent(button.getContext(), Maps.activities.get(id));
        if (id != R.id.btnHelp) {
            Bundle bundle = new Bundle();
            bundle.putInt("poziom", Maps.buttonsSize5.contains(id) ? 5 : 6);
            bundle.putBoolean("isTimer", Maps.buttonsTimer.contains(id));
            if (isUpdateNick) {
                bundle.putString("newNick", nick);
            } else bundle.putString("nick", nick);
                bundle.putString("email",email);
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }

    private void showLocked6() {
        Toast.makeText(getApplicationContext(), "Need " + Config.EDGE_6 + " points at size 5", Toast.LENGTH_LONG).show();
    }

    private boolean isUsableSize6() {
        //return false;
        return podajDAO().isUsableSize6();
    }

    private DAO podajDAO() {
        if (dao == null) dao = new DAO(getApplicationContext());
        return dao;
    }

    private void showAds() {
        AdView mAdView = (AdView) findViewById(R.id.banerMenu);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    private void setNick() {
        nick = podajDAO().getNick();
        email = getEmail();
        if (nick.isEmpty()) {
            if (email.contains("@")) {
                nick = email.split("@")[0];
            } else {
                Date dateStart = new Date();
                dateStart.setYear(117);
                dateStart.setMonth(1);
                dateStart.setDate(1);
                nick = "Player" + ((new Date().getTime() - dateStart.getTime()) / 10000);
            }
            isUpdateNick =true;
        }
        ((EditText) findViewById(R.id.eName)).setText(nick);
    }

    private String getEmail(){
        String email = Utils.getUserEmail(this);
        if (email==null){
            email=Utils.getID(this);
        }
        return email;
    }

    private void updateNick(){
        String newNick=((EditText) findViewById(R.id.eName)).getText().toString();
        if(!isNickCorrect(newNick)) {
            Toast.makeText(getApplicationContext(),"Illegal name\n only letters and numbers \n min 4 charters long",Toast.LENGTH_LONG).show();
            return;
        }
        nick =newNick;
        ((ImageView)findViewById(R.id.btnSave)).setImageDrawable(getResources().getDrawable(R.mipmap.save_off));
        podajDAO().setNick(nick);
        isUpdateNick =true;
        Toast.makeText(getApplicationContext(),"Save successful",Toast.LENGTH_LONG).show();
        findViewById(R.id.layMenuMain).requestFocus();
    }

    private boolean isNickCorrect(String nick){
        String regex ="[a-zA-Z\\d\\s_]{4,}";
        return nick.matches(regex);
    }
}
