package tridoo.sigma;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;


public class MenuActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        ustawPrzyciski();
        uruchomReklamy();
    }


    private void ustawPrzyciski(){

        findViewById(R.id.iv_wyniki5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(),WynikiActivity.class);
                intent.putExtra("poziom", 5);
                startActivity(intent);
            }
        });


        findViewById(R.id.iv_5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(),GraActivity.class);
                intent.putExtra("poziom", 5);
                startActivity(intent);
            }
        });

        if (czyDostepny6()) {
            findViewById(R.id.iv_wyniki6).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(view.getContext(),WynikiActivity.class);
                    intent.putExtra("poziom", 6);
                    startActivity(intent);
                }
            });


            findViewById(R.id.iv_6).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(view.getContext(), GraActivity.class);
                    intent.putExtra("poziom", 6);
                    startActivity(intent);
                }
            });
        } else {
            ImageView level6 = (ImageView) findViewById(R.id.iv_6);
            level6.setImageDrawable(getResources().getDrawable(R.mipmap.kafelek_6_off));

            level6.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    pokazKomunikatZablokowania6();
                    return true;
                }
            });

            ImageView wyniki6 = (ImageView) findViewById(R.id.iv_wyniki6);
            wyniki6.setImageDrawable(getResources().getDrawable(R.mipmap.list_6_off));

            wyniki6.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    pokazKomunikatZablokowania6();
                    return true;
                }
            });

        }
    }

    private void pokazKomunikatZablokowania6(){
        Toast.makeText(getApplicationContext(), "Need "+ Stale.GRANICA_6 +" points at size 5", Toast.LENGTH_LONG).show();
    }

    private boolean czyDostepny6(){
        DAO dao=new DAO(getApplicationContext());
        return dao.czyDostepny6();
    }

    private void uruchomReklamy(){
        AdView mAdView = (AdView) findViewById(R.id.banerMenu);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

}
