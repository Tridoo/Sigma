package tridoo.sigma;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.Layout;
import android.util.Log;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class GraActivity extends Activity {

    int pktNaBonus;
    int maxLiczba;
    int rozmiarPola;
    int tablicaWartosci[][];
    boolean sprawdzonePozycje[][];
    int idWlaczonegoBonusa;
    List<Bonus> listaBonusow;
    int poziom;
    int zdobytePKT;
    List<Integer> paletaKolorow;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gra);
        poziom=getIntent().getIntExtra("poziom",1);
        rozmiarPola = poziom == 6 ? 6 : 5;
        paletaKolorow = podajPaleteTel(rozmiarPola);

        listaBonusow=podajListeBonusow();
        ustawTouchLisenery(listaBonusow);

        nowaGra();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ustawProgresBary();
        uruchomReklamy();
    }

    @Override
    public void onBackPressed() {
        zdobytePKT=podajWynik();
        if(zdobytePKT==0) {
            finish();
            return;
        }

        Dialog dialog;
        final String[] items = {"Save Score"};
        final boolean[] selectedItems={true};

        final ArrayList<Integer> itemsSelected = new ArrayList<>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("End the game?");
        builder.setMultiChoiceItems(items, selectedItems,
                new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId,
                                        boolean isSelected) {
                        if (isSelected) {
                            itemsSelected.add(selectedItemId);
                        } else if (itemsSelected.contains(selectedItemId)) {
                            itemsSelected.remove(Integer.valueOf(selectedItemId));
                        }
                    }
                })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        if (((AlertDialog) dialog).getListView().getCheckedItemPositions().get(0)) zapiszWynik(zdobytePKT);
                        finish();
                    }
                })
                .setNegativeButton("No", null);
        dialog = builder.create();
        dialog.show();
    }

    private void uruchomReklamy(){
        AdView mAdView = (AdView) findViewById(R.id.banerGra);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    private void nowaGra(){
        pktNaBonus=0;
        zdobytePKT=0;
        idWlaczonegoBonusa=-1;
        maxLiczba=1;
        tablicaWartosci=new int[rozmiarPola+2][rozmiarPola+2];
        sprawdzonePozycje=new boolean[rozmiarPola+2][rozmiarPola+2];
        dodajPusteKafelki();
        ustawZrodlo();
        dodajPierwszeKafeleki();
        ustawProgresBary();
        schowajPrzyciski();
        ((TextView)findViewById(R.id.tv_pkt)).setText(String.valueOf(0));
    }

    private List<Integer> podajPaleteTel(int poziom){
        boolean czyPoziom6=poziom==6;

        List<Integer> lista=new ArrayList<>();
        lista.add(R.drawable.bg_round99);
        lista.add(R.drawable.bg_round1);
        if (czyPoziom6)lista.add(R.drawable.bg_round2);
        lista.add(R.drawable.bg_round3);
        if (czyPoziom6)lista.add(R.drawable.bg_round4);
        lista.add(R.drawable.bg_round5);
        if (czyPoziom6)lista.add(R.drawable.bg_round6);
        lista.add(R.drawable.bg_round7);
        if (czyPoziom6)lista.add(R.drawable.bg_round8);
        lista.add(R.drawable.bg_round9);
        if (czyPoziom6)lista.add(R.drawable.bg_round10);
        lista.add(R.drawable.bg_round11);
        if (czyPoziom6)lista.add(R.drawable.bg_round12);
        lista.add(R.drawable.bg_round13);
        if (czyPoziom6)lista.add(R.drawable.bg_round14);
        lista.add(R.drawable.bg_round15);
        lista.add(R.drawable.bg_round16);
        lista.add(R.drawable.bg_round17);
        lista.add(R.drawable.bg_round18);
        lista.add(R.drawable.bg_round19);
        lista.add(R.drawable.bg_round20);

        return lista;
    }

    private int podajKolor(int pkt){
        int rozmiar=paletaKolorow.size();
        if (pkt>=rozmiar) return paletaKolorow.get(rozmiar-1);
        else return paletaKolorow.get(pkt);
    }

    public List<Bonus> podajListeBonusow(){
        List<Bonus> listaBonusow=new ArrayList<>();
        Bonus bomba=new Bonus();
        bomba.setIlePKT(Stale.PKT_BONUS_1);
        bomba.setImg((ImageView)findViewById(R.id.iv_bonus1));
        bomba.setIdImgDisable(R.mipmap.bomb_disable);
        bomba.setIdImgOn(R.mipmap.bomb_on);
        bomba.setIdImgOff(R.mipmap.bomb_off);
        listaBonusow.add(bomba);

        Bonus lPozioma=new Bonus();
        lPozioma.setIlePKT(Stale.PKT_BONUS_2);
        lPozioma.setImg((ImageView)findViewById(R.id.iv_bonus3));
        lPozioma.setIdImgDisable(R.mipmap.l_poziom_disable);
        lPozioma.setIdImgOn(R.mipmap.l_poziom_on);
        lPozioma.setIdImgOff(R.mipmap.l_poziom_off);
        listaBonusow.add(lPozioma);

        Bonus lPion=new Bonus();
        lPion.setIlePKT(Stale.PKT_BONUS_3);
        lPion.setImg((ImageView)findViewById(R.id.iv_bonus2));
        lPion.setIdImgDisable(R.mipmap.l_pion_disable);
        lPion.setIdImgOn(R.mipmap.l_pion_on);
        lPion.setIdImgOff(R.mipmap.l_pion_off);
        listaBonusow.add(lPion);

        Bonus mieszanie=new Bonus();
        mieszanie.setIlePKT(Stale.PKT_BONUS_4);
        mieszanie.setImg((ImageView)findViewById(R.id.iv_bonus4));
        mieszanie.setIdImgDisable(R.mipmap.mieszaj_disable);
        mieszanie.setIdImgOn(R.mipmap.mieszaj_on);
        mieszanie.setIdImgOff(R.mipmap.mieszaj_off);
        listaBonusow.add(mieszanie);
        return listaBonusow;
    }

    private void ustawTouchLisenery(List<Bonus> listaBonusow){
        for (Bonus pBonus:listaBonusow){
            pBonus.getImg().setOnTouchListener(new MyTouchListener());
        }
    }

    private void dodajPusteKafelki(){
        final GridLayout gridLayout=(GridLayout)findViewById(R.id.gridLayout);
        gridLayout.removeAllViews();
        gridLayout.setColumnCount(rozmiarPola);
        gridLayout.setRowCount(rozmiarPola);
        for (int i = 0; i < rozmiarPola; i++) {
            for (int j = 0; j < rozmiarPola; j++) {

                Kafelek textView = new Kafelek(this);
                textView.setBackground(getResources().getDrawable(R.drawable.bg_round));
                textView.setText("   ");
                textView.setTextSize(getResources().getDimension(R.dimen.rozmiar_txt)*0.45f);
                textView.setGravity(Gravity.CENTER);
                textView.setOnDragListener(new MyDragListener());
                textView.setPosInGrid(j+1, i+1);
                textView.setOnTouchListener(new TouchListenerKafelka());

                int marginesKafelka=getResources().getDimensionPixelSize(R.dimen.margines_kafelka);
                GridLayout.LayoutParams gridParam = new GridLayout.LayoutParams();
                gridParam.setMargins(marginesKafelka, marginesKafelka, marginesKafelka, marginesKafelka);
                gridParam.setGravity(Gravity.FILL);
                gridLayout.addView(textView, gridParam);
            }
        }

        gridLayout.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        int marginesKafelka = getResources().getDimensionPixelSize(R.dimen.margines_kafelka);
                        int szerokosc = (int) ((gridLayout.getWidth() - 2 * rozmiarPola * marginesKafelka));
                        int wysokosc = (int) ((gridLayout.getHeight() - 2 * rozmiarPola * marginesKafelka));
                        for (int i = 0; i < rozmiarPola * rozmiarPola; i++) {
                            ((Kafelek) gridLayout.getChildAt(i)).setWidth(szerokosc / rozmiarPola);
                            ((Kafelek) gridLayout.getChildAt(i)).setHeight(wysokosc / rozmiarPola);
                        }
                        gridLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }
                });
    }

    private void ustawZrodlo(){
        TextView tvZrodlo= (TextView)findViewById(R.id.tv_zrodlo);
        tvZrodlo.setText("1");
        tvZrodlo.setOnTouchListener(new MyTouchListener());
        ustawKolor(tvZrodlo,1);
    }

    private void dodajPierwszeKafeleki(){
        Random rnd=new Random();
        int x, y, ile=0;
        Kafelek kafelek;

        do{
            x=rnd.nextInt(rozmiarPola)+1;
            y=rnd.nextInt(rozmiarPola)+1;
            Log.e("ss",x+" "+y);
            if(tablicaWartosci[x][y]==1) continue;
            kafelek=znajdzKafelek(x,y);
            tablicaWartosci[x][y]=1;
            if(podajListeOdpowiednichSasiadow(kafelek).size()>1){
                Log.e("ss","sasiad");
                tablicaWartosci[x][y]=0;
                czyscSprawdzonePozycje();
                continue;
            }
            kafelek.setText(String.valueOf(1));
            ustawKolor(kafelek,1);
            ile++;
            Log.e("ss",ile+" ile");
            czyscSprawdzonePozycje();
        }while(ile<3);
        Log.e("ss","---------------");
    }

    private int losujLiczbe(int aMax) {
        int wielkoscTablicy = 0;

        for (int i = 1; i <= aMax; i++) {
            wielkoscTablicy += i;
        }
        Random rnd = new Random();
        int x = rnd.nextInt(wielkoscTablicy) + 1;

        int tmp = 0;
        for (int i = 0; i < aMax; i++) {
            tmp += (aMax - i);
            if (x <= tmp) return i + 1;
        }
        return 1;
    }

    private final class MyTouchListener implements View.OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                view.startDrag(data, shadowBuilder, view, 0);

                for (int i = 0; i < listaBonusow.size(); i++) {
                    if (view.getId() == listaBonusow.get(i).getImg().getId()) {
                        if (listaBonusow.get(i).getIlePKT() > pktNaBonus) idWlaczonegoBonusa = -1;
                        else {
                            if (idWlaczonegoBonusa == -1) idWlaczonegoBonusa = i;
                            else idWlaczonegoBonusa = -1;
                        }
                    }
                }
                ustawIkoneBonusa(idWlaczonegoBonusa);
                return true;
            } else {
                return false;
            }
        }
    }

    private final class TouchListenerKafelka implements  View.OnTouchListener{
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN){
                Kafelek kafelek=(Kafelek)v;
                if (idWlaczonegoBonusa!=-1){
                    uruchomBonus(kafelek, idWlaczonegoBonusa);
                    ustawIkoneBonusa(idWlaczonegoBonusa);
                    return true;
                }
                if (kafelek.getText().length() == 3) {
                    String liczba = ((TextView) findViewById(R.id.tv_zrodlo)).getText().toString();
                    kafelek.setText(liczba);
                    sprawdzKafelek(kafelek, liczba);
                    return true;
                }
            }
            return false;
        }
    }

    private final class MyDragListener implements View.OnDragListener {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    break;
                case DragEvent.ACTION_DRAG_ENTERED:
                    if (((TextView) v).getText().length()==3) ustawKolor((TextView) v,-1);
                    break;
                case DragEvent.ACTION_DRAG_EXITED:
                    if (((TextView) v).getText().length()==3) ustawKolor((TextView) v,0);
                    break;
                case DragEvent.ACTION_DROP:
                    View view = (View) event.getLocalState();
                    Kafelek container = (Kafelek) v;
                    if (view instanceof TextView) {
                        TextView tv = (TextView) view;
                        if (container.getText().length() == 3)
                            sprawdzKafelek(container, tv.getText().toString());
                    } else if (view instanceof ImageView){
                        if (czyBonusAktywny((ImageView) view)) {
                            uruchomBonus(container, (ImageView) view);
                        }
                        else {
                            if (container.getText().toString().equals("   ")) ustawKolor(container,0);
                            else ustawKafelek(container,Integer.valueOf(container.getText().toString()));
                        }
                    }
                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                default:
                    break;
            }
            return true;
        }
    }

    private boolean czyBonusAktywny(ImageView view){
        for (Bonus pBonus:listaBonusow){
            if (pBonus.getImg().getId()==view.getId()){
                return pBonus.getIlePKT() < pktNaBonus;
            }
        }
        return false;
    }

    private void uruchomBonus(Kafelek kafelek, int idBonusa) {
        uruchomBonus(kafelek, listaBonusow.get(idBonusa).getImg());
    }

    private void uruchomBonus(Kafelek kafelek, ImageView bonus) {
        Set<Kafelek> listaKafelkow = new HashSet<>();

        if (bonus.getId()==listaBonusow.get(0).getImg().getId()){
            if (pktNaBonus>listaBonusow.get(0).getIlePKT()){
                listaKafelkow.add(kafelek);
                czyscKafeki(listaKafelkow);
                pktNaBonus-=listaBonusow.get(0).getIlePKT();
            }

        } else  if (bonus.getId()==listaBonusow.get(1).getImg().getId()){
            if (pktNaBonus>listaBonusow.get(1).getIlePKT()){
                int y = kafelek.getPosInGrid()[1];
                for (int i = 1; i < rozmiarPola+1; i++) {
                    listaKafelkow.add(znajdzKafelek(i, y));
                }
                czyscKafeki(listaKafelkow);
                pktNaBonus-=listaBonusow.get(1).getIlePKT();
            }

        } else  if (bonus.getId()==listaBonusow.get(2).getImg().getId()){
            if (pktNaBonus>listaBonusow.get(2).getIlePKT()){
                int x = kafelek.getPosInGrid()[0];
                for (int i = 1; i < rozmiarPola+1; i++) {
                    listaKafelkow.add(znajdzKafelek(x, i));
                }
                czyscKafeki(listaKafelkow);
                pktNaBonus-=listaBonusow.get(2).getIlePKT();
            }

        } else if (bonus.getId()==listaBonusow.get(3).getImg().getId()){
            if (pktNaBonus>listaBonusow.get(3).getIlePKT()){
                HashMap<Integer, Integer> wystapieniaLiczb = policzWystapieniaLiczb();
                czyscWszystko();

                Iterator it = wystapieniaLiczb.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry pair = (Map.Entry) it.next();
                    int ile = (int) pair.getValue();
                    int liczba = (int) pair.getKey();
                    for (int i = 0; i < ile; i++) {
                        Point punkt = losujPustaPozycje();
                        ustawKafelek(znajdzKafelek(punkt.x, punkt.y), liczba);
                    }
                }
                pktNaBonus-=listaBonusow.get(3).getIlePKT();
                sprawdzKafelkiPoMieszaniu();
            }
        }
        idWlaczonegoBonusa=-1;
        sprawdzicDostepneBonusy();
        ustawProgresBary();
    }

    private void sprawdzKafelek(Kafelek kafelek, String aWartosc){
        boolean czyBylyZmiany=false;
        kafelek.setText(aWartosc);
        int pWartosc=Integer.valueOf(aWartosc);
        tablicaWartosci[kafelek.getPosInGrid()[0]][kafelek.getPosInGrid()[1]]=pWartosc;
        ustawKolor(kafelek,pWartosc);

        Set<Kafelek> pListaOdpowiednichSasiadow=podajListeOdpowiednichSasiadow(kafelek);

        if (pListaOdpowiednichSasiadow.size()>2) {
            if (pWartosc==maxLiczba) maxLiczba++;
            czyscKafeki(pListaOdpowiednichSasiadow);
            kafelek.setText(String.valueOf(pWartosc+1));
            tablicaWartosci[kafelek.getPosInGrid()[0]][kafelek.getPosInGrid()[1]]=pWartosc+1;
            ustawKolor(kafelek,pWartosc+1);
            int pkt=ilePunktowDodac(pWartosc,pListaOdpowiednichSasiadow.size());
            pktNaBonus+=pkt;
            dodajPKT(pkt);
            czyBylyZmiany=true;
            animujIkonyBonusow(pkt);
        }
         if (czyKoniecGry()) {
            zdobytePKT=podajWynik();
            pokazKoniec();
            zapiszWynik(zdobytePKT);
            udostepnijWynik(zdobytePKT);
            dodajPrzyciskiRestartWyjscie();
        }
        else {
            int nowaLiczba = losujLiczbe(maxLiczba);
            TextView zrodlo = (TextView) findViewById(R.id.tv_zrodlo);
            zrodlo.setText(String.valueOf(nowaLiczba));
            ustawKolor(zrodlo, nowaLiczba);
            czyscSprawdzonePozycje();
            if (czyBylyZmiany) sprawdzKafelek(kafelek, String.valueOf(pWartosc + 1));
            sprawdzicDostepneBonusy();
            ustawProgresBary();
        }
    }

    private Set<Kafelek> podajListeOdpowiednichSasiadow(Kafelek aKafelek){
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];
        int pWartosc=tablicaWartosci[pX][pY];

        sprawdzonePozycje[pX][pY]=true;
        Set<Kafelek> listaDoZamiany=new HashSet<>();
        listaDoZamiany.add(aKafelek);
        List<Kafelek> listaDoSprawdzenia=new ArrayList<>();
        List<Kafelek> tmp=podajFiltrowanaListeSasiadow(aKafelek, pWartosc);
        listaDoZamiany.addAll(tmp);
        listaDoSprawdzenia.addAll(tmp);

        ListIterator<Kafelek> iterator = listaDoSprawdzenia.listIterator();
        while (iterator.hasNext()) {
            Kafelek pKafelek = iterator.next();
            tmp=podajFiltrowanaListeSasiadow(pKafelek, pWartosc);
            if (!tmp.isEmpty()){
                listaDoZamiany.addAll(tmp);
                for (Kafelek aSasiad: tmp){
                    iterator.add(aSasiad);
                    iterator.previous();
                }
            }
        }
        return listaDoZamiany;
    }

    private List<Kafelek> podajFiltrowanaListeSasiadow(Kafelek aKafelek, int aWartosc){
        List<Kafelek> pListaSasiadow=new ArrayList<>();
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];

        for (Point wspolrzedna : podajWspolrzedneSasiadow()) {
            if (czyDodacSasiada(pX-wspolrzedna.x, pY-wspolrzedna.y, aWartosc))
                pListaSasiadow.add(znajdzKafelek(pX-wspolrzedna.x, pY-wspolrzedna.y));
        }
        sprawdzonePozycje[pX][pY]=true;
        return pListaSasiadow;
    }

    private List<Point> podajWspolrzedneSasiadow(){
        List<Point> lista=new ArrayList<>();
        lista.add(new Point(-1,0));
        lista.add(new Point(1,0));
        lista.add(new Point(0,-1));
        lista.add(new Point(0,1));
        return lista;
    }

    private boolean czyDodacSasiada(int x, int y, int wartosc){
        return (!sprawdzonePozycje[x][y] && tablicaWartosci[x][y]==wartosc);
    }

    @Nullable
    private Kafelek znajdzKafelek(int x, int y){
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i = 0; i < ileKafelkow; i++) {
            Kafelek pKafelek = (Kafelek) gridLayout.getChildAt(i);
            if ((pKafelek.getPosInGrid()[0]==x) && (pKafelek.getPosInGrid()[1]==y)) return pKafelek;
        }
        return null;
    }

    private void czyscSprawdzonePozycje() {
        for (int i = 0; i < rozmiarPola + 2; i++) {
            for (int j = 0; j < rozmiarPola + 2; j++) {
                sprawdzonePozycje[i][j] = false;
            }
        }
    }

    private void ustawKolor(TextView kafelek, int pkt){
        kafelek.setBackground(getResources().getDrawable(podajKolor(pkt+1)));
    }

    private void czyscKafeki(Set<Kafelek> aLista){
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();

        for(Kafelek pKafelek:aLista){
            pKafelek.setBackground(getResources().getDrawable(R.drawable.bg_round));
            int pX=pKafelek.getPosInGrid()[0];
            int pY=pKafelek.getPosInGrid()[1];
            for (int i=0; i<ileKafelkow;i++){
                if (((Kafelek)gridLayout.getChildAt(i)).getPosInGrid()[0]==pX &&((Kafelek)gridLayout.getChildAt(i)).getPosInGrid()[1]==pY) {
                    ((Kafelek)gridLayout.getChildAt(i)).setText("   ");
                    tablicaWartosci[pX][pY]=0;
                    break;
                }
            }
        }
    }

    private void czyscWszystko(){
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i = 0; i < ileKafelkow; i++) {
            Kafelek pKafelek=((Kafelek) gridLayout.getChildAt(i));
            pKafelek.setText("   ");
            tablicaWartosci[pKafelek.getPosInGrid()[0]][pKafelek.getPosInGrid()[1]]=0;
            ustawKolor(pKafelek,0);
        }
    }

    private HashMap<Integer,Integer> policzWystapieniaLiczb() {
        HashMap<Integer, Integer> wystapieniaLiczb = new HashMap<>();
        int rozmiar = tablicaWartosci.length;

        for (int i = 0; i < rozmiar; i++) {
            for (int j = 0; j < rozmiar; j++) {
                int wartosc = tablicaWartosci[i][j];
                if (wartosc == 0) continue;
                wystapieniaLiczb.put(wartosc, wystapieniaLiczb.get(wartosc) == null ? 1 : wystapieniaLiczb.get(wartosc) + 1);
            }
        }
        return wystapieniaLiczb;
    }

    private Point losujPustaPozycje() {
        Point punkt = new Point();
        Random rnd = new Random();
        int x, y;
        do {
            x = rnd.nextInt(rozmiarPola) + 1;
            y = rnd.nextInt(rozmiarPola) + 1;

        } while (tablicaWartosci[x][y] != 0);
        punkt.x = x;
        punkt.y = y;
        return punkt;
    }

    private void ustawKafelek(Kafelek aKafelek, int aWartosc){
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];
        tablicaWartosci[pX][pY]=aWartosc;
        aKafelek.setText(String.valueOf(aWartosc));
        ustawKolor(aKafelek,aWartosc);
    }

    private int ilePunktowDodac(int liczba, int ileKafelkow){
        return (int)(liczba*ileKafelkow*Math.pow(1.15, liczba-1)*(1.1*(ileKafelkow-2)));
    }

    private void dodajPKT(int pkt){
        TextView tv=(TextView)findViewById(R.id.tv_pkt);
        int aktualnaPKT=Integer.valueOf(tv.getText().toString());
        tv.setText(String.valueOf(aktualnaPKT+pkt));
    }

    private int podajWynik(){
        TextView tv=(TextView)findViewById(R.id.tv_pkt);
        return Integer.valueOf(tv.getText().toString());
    }

    private void sprawdzicDostepneBonusy() {
        for (Bonus pBonus:listaBonusow){
            if (pktNaBonus>=pBonus.getIlePKT()) pBonus.getImg().setImageDrawable(getResources().getDrawable(pBonus.getIdImgOff()));
            else pBonus.getImg().setImageDrawable(getResources().getDrawable(pBonus.getIdImgDisable()));
        }
    }

    private void ustawProgresBary(){
        int progres1=(pktNaBonus*100)/Stale.PKT_BONUS_1;
        int progres2=(pktNaBonus*100)/Stale.PKT_BONUS_2;
        int progres3=(pktNaBonus*100)/Stale.PKT_BONUS_3;
        int progres4=(pktNaBonus*100)/Stale.PKT_BONUS_4;

        ustawProgresBar((ProgressBar)findViewById(R.id.progressBar1),progres1,(TextView)findViewById(R.id.px1));
        ustawProgresBar((ProgressBar)findViewById(R.id.progressBar2),progres2,(TextView)findViewById(R.id.px2));
        ustawProgresBar((ProgressBar)findViewById(R.id.progressBar3),progres3,(TextView)findViewById(R.id.px3));
        ustawProgresBar((ProgressBar)findViewById(R.id.progressBar4),progres4,(TextView)findViewById(R.id.px4));
    }

    private void ustawProgresBar(ProgressBar progressBar, int procent, TextView krotnosc){
        if (procent>99) {
            krotnosc.setText(String.valueOf((int)(procent/100)));
            procent=100;
        }
        else {
            krotnosc.setText("");
        }
        progressBar.setProgress(procent);

    }

    private void animujIkonyBonusow(int pkt){
        int pktPrzed=pktNaBonus-pkt;
        for (Bonus pBonus:listaBonusow){
            if (pBonus.getIlePKT()<=pktNaBonus && pBonus.getIlePKT()>pktPrzed) animujIkoneBonusa(pBonus.getImg());
        }
    }

    private void animujIkoneBonusa(ImageView iv){
        Animation animZoom;
        animZoom = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom);
        iv.startAnimation(animZoom);
    }

    private void ustawIkoneBonusa(int idBonusa){
        sprawdzicDostepneBonusy();
        if (idBonusa!=-1) listaBonusow.get(idBonusa).getImg().setImageDrawable(getResources().getDrawable(listaBonusow.get(idBonusa).getIdImgOn()));
    }

    private void sprawdzKafelkiPoMieszaniu(){
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i = 0; i < ileKafelkow; i++) {
            Kafelek pKafelek = (Kafelek) gridLayout.getChildAt(i);
            if (pKafelek.getText().length() != 3)
                sprawdzKafelek(pKafelek, pKafelek.getText().toString());
        }
    }

    private boolean czyKoniecGry() {
        if (pktNaBonus > Stale.PKT_BONUS_1) return false;

        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i = 0; i < ileKafelkow; i++) {
            Kafelek pKafelek = (Kafelek) gridLayout.getChildAt(i);
            if (pKafelek.getText().length() == 3) return false;
        }
        return true;
    }

    private void pokazKoniec(){
        LinearLayout lay=(LinearLayout) findViewById(R.id.lay_gra_koniec);
        ImageView end=new ImageView(this);
        end.setImageResource(R.mipmap.end);
        lay.addView(end);
    }

    private void zapiszWynik(int pkt){
        DAO dao=new DAO(getApplicationContext());
        dao.dodajWynik(pkt,poziom);
        if (pkt>Stale.GRANICA_6) dao.ustawDostepny6();
    }

    private void udostepnijWynik(final int pkt){
        LinearLayout lay=(LinearLayout) findViewById(R.id.lay_gra_koniec);
        ImageView share=new ImageView(this);
        if (pkt >= Stale.GRANICA_UDOSTEPNIENIA) {
            share.setImageResource(R.mipmap.share_on);
            share.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    wyslijWynik(pkt);
                    return true;
                }
            });
        } else {
            share.setImageResource(R.mipmap.share_off);
            share.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    Toast.makeText(getApplicationContext(), "Need "+ Stale.GRANICA_UDOSTEPNIENIA +" points", Toast.LENGTH_LONG).show();
                    return false;
                }
            });

        }
        lay.addView(share);
    }

    private void wyslijWynik(int pkt){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},Stale.ZEZWOLENIE);
            } else {
                ActivityCompat.requestPermissions(this,  new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Stale.ZEZWOLENIE);
            }
        } else {
            udostepnij(pkt);
        }
    }

    private void udostepnij(int pkt){
        int id_bmp_wynikow;
        if (poziom==5) id_bmp_wynikow=R.mipmap.wynik5;
        else id_bmp_wynikow=R.mipmap.wynik6;

        Bitmap icon = BitmapFactory.decodeResource(getApplicationContext().getResources(), id_bmp_wynikow);

        Bitmap workingBitmap = Bitmap.createBitmap(icon);
        Bitmap mutableBitmap = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(mutableBitmap);
        Paint paint = new Paint();
        paint.setColor(Color.RED);
        paint.setAntiAlias(true);
        paint.setTextSize(canvas.getHeight()/3);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(String.valueOf(pkt), (canvas.getWidth() / 1.7f) , (canvas.getHeight() / 1.5f), paint);

        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("image/jpeg");

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "Game score");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        OutputStream outstream;
        try {
            outstream = getContentResolver().openOutputStream(uri);
            mutableBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outstream);
            outstream.close();
        } catch (Exception e) {
            System.err.println(e.toString());
        }

        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.putExtra(Intent.EXTRA_TEXT, "New score: "+ pkt+" points");
        startActivity(Intent.createChooser(share, "Share Image"));
    }

    private void dodajPrzyciskiRestartWyjscie(){
        RelativeLayout lay = (RelativeLayout) findViewById(R.id.lay);

        ImageView exit= new ImageView(getApplicationContext());
        exit.setImageDrawable(getResources().getDrawable(R.mipmap.exit));
        exit.setTag("tmp");
        RelativeLayout.LayoutParams paramsExit= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsExit.setMargins(20,20,20,20);
        paramsExit.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        lay.addView(exit,paramsExit);

        final ImageView restart= new ImageView(getApplicationContext());
        restart.setImageDrawable(getResources().getDrawable(R.mipmap.restart));
        restart.setTag("tmp");
        RelativeLayout.LayoutParams paramsRestart= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsRestart.setMargins(20,20,20,20);
        paramsRestart.addRule(RelativeLayout.ALIGN_PARENT_END);
        paramsRestart.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        lay.addView(restart,paramsRestart);

        exit.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                wyjscie();
                return true;
            }
        });

        restart.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                nowaGra();
                return true;
            }
        });

    }

    private void wyjscie(){
        finish();
    }

    private void schowajPrzyciski(){
        LinearLayout layLin = (LinearLayout) findViewById(R.id.lay_gra_koniec);
        layLin.removeAllViews();

        RelativeLayout lay = (RelativeLayout) findViewById(R.id.lay);
        List <View> listaDoUsuniecia=new ArrayList<>();
        int ile=lay.getChildCount();
        for (int i=0;i<ile;i++){
            View view=lay.getChildAt(i);
            if (view instanceof ImageView){
                if (view.getTag().equals("tmp")) listaDoUsuniecia.add(view);
            }
        }
        for(View view:listaDoUsuniecia) {
            lay.removeView(view);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,  String permissions[], int[] grantResults) {
        switch (requestCode) {
            case Stale.ZEZWOLENIE: {
                if (grantResults.length > 0  && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    udostepnij(zdobytePKT);
                } else {
                    // brak uprawnien
                }
                return;
            }

        }
    }
}