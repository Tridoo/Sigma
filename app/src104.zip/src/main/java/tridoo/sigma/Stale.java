package tridoo.sigma;

public class Stale {
    public static final int GRANICA_6=6000;
    public static final int GRANICA_UDOSTEPNIENIA=1000;
    public static final int PKT_BONUS_1=270;
    public static final int PKT_BONUS_2=350;
    public static final int PKT_BONUS_3=350;
    public static final int PKT_BONUS_4=500;
    public static final int ZEZWOLENIE = 777;
}
