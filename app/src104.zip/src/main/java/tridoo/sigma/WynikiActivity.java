package tridoo.sigma;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.Collections;
import java.util.List;

public class WynikiActivity extends Activity {
    int poziom;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wyniki);
        uruchomReklamy();
        poziom=getIntent().getIntExtra("poziom",1);

        DAO dao=new DAO(getApplicationContext());
        wypelnijtabeleWynikow(dao.odczytajWyniki(poziom));
    }

    private void uruchomReklamy(){
        AdView mAdView = (AdView) findViewById(R.id.banerWyniki);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    private void wypelnijtabeleWynikow(List<Integer> listaWynikow){
        Collections.reverse(listaWynikow);
        LinearLayout scroll=(LinearLayout) findViewById(R.id.lin_lay);

        int id_bmp;
        if (poziom==5) id_bmp=R.mipmap.rozmiar_5;
        else id_bmp=R.mipmap.rozmiar_6;

        ImageView naglowek=new ImageView(this);
        naglowek.setImageDrawable(getResources().getDrawable(id_bmp));
        scroll.addView(naglowek);

        TextView textView;
        for (int i = 0; i < listaWynikow.size(); i++) {
            String wynik=(i+1)+". "+listaWynikow.get(i);
            textView = new TextView(this);
            textView.setText(wynik);
            textView.setTextSize(getResources().getDimension(R.dimen.rozmiar_txt)*0.5f);
            textView.setGravity(Gravity.CENTER_HORIZONTAL);
            textView.setBackground(getResources().getDrawable(R.drawable.bottom));
            textView.setPadding(0,15,0,0);
            scroll.addView(textView);
        }
    }
}
