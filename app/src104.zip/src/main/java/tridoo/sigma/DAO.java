package tridoo.sigma;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class DAO {
    private Context context;

    public DAO(Context aContext) {
        context = aContext;
    }

    public List<Integer> odczytajWyniki(int poziom) {
        String jStringName = stringPoziomu(poziom);

        List<Integer> listaWynikow = new ArrayList<>();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        String jString = prefs.getString(jStringName, "");
        try {
            JSONArray jWszystkieWyniki = new JSONArray(jString);
            for (int i = 0; i < jWszystkieWyniki.length(); i++) {
                listaWynikow.add(jWszystkieWyniki.getInt(i));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return listaWynikow;
    }

    private void zapiszWyniki(List<Integer> aListaWynikow, int poziom) {
        String jStringName = stringPoziomu(poziom);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        JSONArray jWyniki = new JSONArray();

        for (Integer wynik : aListaWynikow) {
            jWyniki.put(wynik);
        }

        editor.putString(jStringName, jWyniki.toString());
        editor.apply();
    }

    public void dodajWynik(int wynik, int poziom) {
        List<Integer> wyniki = odczytajWyniki(poziom);
        wyniki.add(wynik);
        Collections.sort(wyniki);
        zapiszWyniki(wyniki, poziom);
    }

    public boolean czyDostepny6(){
        String jStringName = "czy6";
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return  prefs.getBoolean(jStringName, false);
    }

    public void ustawDostepny6(){
        String jStringName = "czy6";
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(jStringName, true);
        editor.apply();
    }

    private String stringPoziomu(int poziom){
        switch (poziom) {
            case 5:
                return "wyniki5";
            case 6:
                return "wyniki6";
        }
        return null;
    }
}
