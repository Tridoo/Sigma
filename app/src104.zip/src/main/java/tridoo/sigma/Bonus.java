package tridoo.sigma;

import android.widget.ImageView;


public class Bonus {
    private int ilePKT;
    private int idImgOff, idImgOn, idImgDisable;
    private ImageView img;

    public int getIlePKT() {
        return ilePKT;
    }

    public void setIlePKT(int ilePKT) {
        this.ilePKT = ilePKT;
    }

    public int getIdImgOff() {
        return idImgOff;
    }

    public void setIdImgOff(int idImgOff) {
        this.idImgOff = idImgOff;
    }

    public int getIdImgOn() {
        return idImgOn;
    }

    public void setIdImgOn(int idImgOn) {
        this.idImgOn = idImgOn;
    }

    public int getIdImgDisable() {
        return idImgDisable;
    }

    public void setIdImgDisable(int idImgDisable) {
        this.idImgDisable = idImgDisable;
    }

    public ImageView getImg() {
        return img;
    }

    public void setImg(ImageView img) {
        this.img = img;
    }
}
