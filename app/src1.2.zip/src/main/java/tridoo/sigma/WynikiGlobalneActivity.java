package tridoo.sigma;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;


public class WynikiGlobalneActivity extends Activity {
    int poziom;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wyniki_globalne);
        String plik=podajNazwePlikuFTP();
        String nowaXywa=podajNowaXywe();
        generujNaglowek();
        if( nowaXywa!=null ) {
            new FtpTask(this).execute(plik,podajEmail(),nowaXywa);
        }
        else new FtpTask(this).execute(plik);
        //todo progressBar
    }

    private void generujNaglowek(){
        LinearLayout scroll=(LinearLayout) findViewById(R.id.lin_lay_global);
        int id_bmp;
        poziom=getIntent().getIntExtra("poziom",1);
        if (poziom==5) id_bmp=R.mipmap.rozmiar_5;
        else id_bmp=R.mipmap.rozmiar_6;

        ImageView naglowek=new ImageView(this);
        naglowek.setImageDrawable(getResources().getDrawable(id_bmp));
        scroll.addView(naglowek);
    }


    private void dodajWynik(String xywa, int pkt, LinearLayout layout,LinearLayout.LayoutParams params, float rozmiarTxt){
        TextView text =new TextView(this);
        text.setText(xywa+" "+pkt);
        text.setTextSize(rozmiarTxt);
        text.setGravity(Gravity.CENTER);
        text.setLayoutParams(params);
        layout.addView(text);
    }

    protected void dodajWyniki(HashMap<String,Integer> mapaWynikow){
        LinearLayout layout=(LinearLayout)findViewById(R.id.lin_lay_global);
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        float rozmiarTxt=getResources().getDimension(R.dimen.rozmiar_normal);
        for (Map.Entry<String, Integer> entry : mapaWynikow.entrySet())
        {
            dodajWynik(entry.getKey(),entry.getValue(),layout, params,rozmiarTxt);
        }
    }

    private String podajNazwePlikuFTP() {
        String nazwa = "wyniki_";
        poziom = getIntent().getIntExtra("poziom", 1);
        boolean czyTimer = getIntent().getBooleanExtra("czyTimer", false);
        nazwa += poziom == 5 ? "5_" : "6_";
        nazwa += czyTimer ? "t" : "a";
        return nazwa+=".txt";
    }

    private String podajNowaXywe(){
        return getIntent().getStringExtra("nowaXywa");
    }

    private String podajEmail(){
        return getIntent().getStringExtra("email");
    }

}