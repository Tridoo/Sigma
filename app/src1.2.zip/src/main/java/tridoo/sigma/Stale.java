package tridoo.sigma;

import android.graphics.Point;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Stale {
    public static final int GRANICA_6=6000;
    public static final int GRANICA_UDOSTEPNIENIA_ARCADE=1000;
    public static final int GRANICA_UDOSTEPNIENIA_TIMER=100;
    public static final int PKT_BONUS_1=200;
    public static final int PKT_BONUS_2=250;
    public static final int PKT_BONUS_3=450;
    public static final int PKT_BONUS_4=550;
    public static final int ZEZWOLENIE = 777;
    public static final int ZEZWOLENIE2 = 778;
    public static final int ILE_NA_STARCIE=5;
    public static final int CZAS_TIMERA=60;

    public static final List<Point> wspolrzedneSasiadow = Arrays.asList(
            new Point(-1,0),
            new Point(1,0),
            new Point(0,-1),
            new Point(0,1)
    );

    public static final HashMap<Integer,Class> mapaAktywnosci;
    static {
        mapaAktywnosci=new HashMap<>();
        mapaAktywnosci.put(R.id.iv_help,HelpActivity.class);
        mapaAktywnosci.put(R.id.iv_5,GraArcadeActivity.class);
        mapaAktywnosci.put(R.id.iv_timer5,GraTimerActivity.class);
        mapaAktywnosci.put(R.id.iv_wyniki5,WynikiActivity.class);
        mapaAktywnosci.put(R.id.iv_wyniki5_g,WynikiGlobalneActivity.class);
        mapaAktywnosci.put(R.id.iv_wyniki5_t,WynikiActivity.class);
        mapaAktywnosci.put(R.id.iv_wyniki5_g_t,WynikiGlobalneActivity.class);

        mapaAktywnosci.put(R.id.iv_6,GraArcadeActivity.class);
        mapaAktywnosci.put(R.id.iv_timer6,GraTimerActivity.class);
        mapaAktywnosci.put(R.id.iv_wyniki6,WynikiActivity.class);
        mapaAktywnosci.put(R.id.iv_wyniki6_g,WynikiGlobalneActivity.class);
        mapaAktywnosci.put(R.id.iv_wyniki6_t,WynikiActivity.class);
        mapaAktywnosci.put(R.id.iv_wyniki6_g_t,WynikiGlobalneActivity.class);
    }

    public static final List<Integer> listaPrzyciskowRozmiar5;
    static {
        listaPrzyciskowRozmiar5 =new ArrayList<>();
        listaPrzyciskowRozmiar5.add(R.id.iv_5);
        listaPrzyciskowRozmiar5.add(R.id.iv_timer5);
        listaPrzyciskowRozmiar5.add(R.id.iv_wyniki5);
        listaPrzyciskowRozmiar5.add(R.id.iv_wyniki5_g);
        listaPrzyciskowRozmiar5.add(R.id.iv_wyniki5_t);
        listaPrzyciskowRozmiar5.add(R.id.iv_wyniki5_g_t);
    }

    public static final List<Integer> listaTimer; //tylko dla wynikow
    static{
        listaTimer=new ArrayList<>();
        listaTimer.add(R.id.iv_timer5);
        listaTimer.add(R.id.iv_wyniki5_t);
        listaTimer.add(R.id.iv_wyniki5_g_t);
        listaTimer.add(R.id.iv_timer6);
        listaTimer.add(R.id.iv_wyniki6_t);
        listaTimer.add(R.id.iv_wyniki6_g_t);
    }

    public static HashMap<Integer,Integer> mapaPrzyciskow6;
    static{
        mapaPrzyciskow6=new HashMap<>();
        mapaPrzyciskow6.put(R.id.iv_6,R.mipmap.kafelek_6_off);
        mapaPrzyciskow6.put(R.id.iv_timer6,R.mipmap.timer_6_off);
        mapaPrzyciskow6.put(R.id.iv_wyniki6,R.mipmap.list_6_off);
        mapaPrzyciskow6.put(R.id.iv_wyniki6_t,R.mipmap.list_6t_off);
        mapaPrzyciskow6.put(R.id.iv_wyniki6_g,R.mipmap.puchar_6_off);
        mapaPrzyciskow6.put(R.id.iv_wyniki6_g_t,R.mipmap.puchar_6_t_off);
    }

}
