package tridoo.sigma;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.Date;
import java.util.Map;


public class MenuActivity extends Activity {
    DAO dao;
    String xywa,email;
    boolean czyAktualizacjaXywy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        ustawXywe();
        ustawPrzyciski();

        //uruchomReklamy();
    }


    private void ustawPrzyciski() {
        findViewById(R.id.iv_help).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uruchomAktywnosc(view);
            }
        });

        for(int id: Stale.listaPrzyciskowRozmiar5){
            findViewById(id).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    uruchomAktywnosc(view);
                }
            });
        }

        for (Map.Entry<Integer, Integer> entry : Stale.mapaPrzyciskow6.entrySet()){
            ImageView imageView=(ImageView) findViewById(entry.getKey());
            if (!czyDostepny6()) imageView.setImageDrawable(getResources().getDrawable(entry.getValue()));
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (czyDostepny6()) {
                        uruchomAktywnosc(view);
                    } else {
                        pokazKomunikatZablokowania6();
                    }
                }
            });
        }

        final ImageView btnSave=(ImageView)findViewById(R.id.iv_save);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aktualizacjaXywy();
            }
        });

        TextWatcher watcher= new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {            }
            public void onTextChanged(CharSequence s, int start, int before, int count) {            }
            @Override
            public void afterTextChanged(Editable s) {
                btnSave.setImageDrawable(getResources().getDrawable(R.mipmap.save));
            }
        };
        ((EditText)findViewById(R.id.e_nick)).addTextChangedListener(watcher);
    }


    private void uruchomAktywnosc(View przycisk) {
        int id = przycisk.getId();
        Intent intent = new Intent(przycisk.getContext(), Stale.mapaAktywnosci.get(id));
        if (id != R.id.iv_help) {
            Bundle bundle = new Bundle();
            bundle.putInt("poziom", Stale.listaPrzyciskowRozmiar5.contains(id) ? 5 : 6);
            bundle.putBoolean("czyTimer", Stale.listaTimer.contains(id));
            if (czyAktualizacjaXywy) {
                bundle.putString("nowaXywa", xywa);
            } else bundle.putString("xywa", xywa);
                bundle.putString("email",email);
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }

    private void pokazKomunikatZablokowania6() {
        Toast.makeText(getApplicationContext(), "Need " + Stale.GRANICA_6 + " points at size 5", Toast.LENGTH_LONG).show();
    }

    private boolean czyDostepny6() {
        return podajDAO().czyDostepny6();
    }

    private DAO podajDAO() {
        if (dao == null) dao = new DAO(getApplicationContext());
        return dao;
    }

    private void uruchomReklamy() {
        AdView mAdView = (AdView) findViewById(R.id.banerMenu);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    private void ustawXywe() {
        xywa = podajDAO().podajXywe();
        email = podajeEmail();
        if (xywa.isEmpty()) {
            if (email.contains("@")) {
                xywa = email.split("@")[0];
            } else {
                Date dataStart = new Date();
                dataStart.setYear(117);
                dataStart.setMonth(1);
                dataStart.setDate(1);
                xywa = "Player" + ((new Date().getTime() - dataStart.getTime()) / 10000);
            }
            czyAktualizacjaXywy=true;
        }
        ((EditText) findViewById(R.id.e_nick)).setText(xywa);
    }

    private String podajeEmail(){
        String email = Utils.getUserEmail(this);
        if (email==null){
            email=Utils.getID(this);
        }
        return email;
    }

    private void aktualizacjaXywy(){
        String pXywa=((EditText) findViewById(R.id.e_nick)).getText().toString();
        if(!czyXywaPoprawna(pXywa)) {
            Toast.makeText(getApplicationContext(),"Illegal name\n only letters and numbers \n min 4 charters long",Toast.LENGTH_LONG).show();
            return;
        }
        xywa=pXywa;
        ((ImageView)findViewById(R.id.iv_save)).setImageDrawable(getResources().getDrawable(R.mipmap.save_off));
        podajDAO().ustawXywe(xywa);
        czyAktualizacjaXywy=true;
        Toast.makeText(getApplicationContext(),"Save successful",Toast.LENGTH_LONG).show();
    }

    private boolean czyXywaPoprawna(String xywa){
        String regex ="[a-zA-Z\\d\\s_]{4,}";
        return xywa.matches(regex);
    }
}
