package tridoo.sigma;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class Utils {
    static List<Integer> podajPaleteTel(int poziom) {
        boolean czyPoziom6 = poziom == 6;

        List<Integer> lista = new ArrayList<>();
        lista.add(R.drawable.bg_round99);
        lista.add(R.drawable.bg_round);
        lista.add(R.drawable.bg_round1);
        if (czyPoziom6) lista.add(R.drawable.bg_round2);
        lista.add(R.drawable.bg_round3);
        if (czyPoziom6) lista.add(R.drawable.bg_round4);
        lista.add(R.drawable.bg_round5);
        if (czyPoziom6) lista.add(R.drawable.bg_round6);
        lista.add(R.drawable.bg_round7);
        if (czyPoziom6) lista.add(R.drawable.bg_round8);
        lista.add(R.drawable.bg_round9);
        if (czyPoziom6) lista.add(R.drawable.bg_round10);
        lista.add(R.drawable.bg_round11);
        if (czyPoziom6) lista.add(R.drawable.bg_round12);
        lista.add(R.drawable.bg_round13);
        if (czyPoziom6) lista.add(R.drawable.bg_round14);
        lista.add(R.drawable.bg_round15);
        if (czyPoziom6) lista.add(R.drawable.bg_round16);
        lista.add(R.drawable.bg_round17);
        lista.add(R.drawable.bg_round18);
        if (czyPoziom6) lista.add(R.drawable.bg_round19);
        lista.add(R.drawable.bg_round20);
        if (czyPoziom6) lista.add(R.drawable.bg_round21);
        lista.add(R.drawable.bg_round22);

        return lista;
    }

    static int losujLiczbe(int aMax) {
        int wielkoscTablicy = 0;

        for (int i = 1; i <= aMax; i++) {
            wielkoscTablicy += i;
        }
        Random rnd = new Random();
        int x = rnd.nextInt(wielkoscTablicy) + 1;

        int tmp = 0;
        for (int i = 0; i < aMax; i++) {
            tmp += (aMax - i);
            if (x <= tmp) return i + 1;
        }
        return 1;
    }

    static int ilePunktowDodac(int liczba, int ileKafelkow) {
        return (int) (liczba * ileKafelkow * Math.pow(1.15, liczba - 1) * (1.1 * (ileKafelkow - 2)));
    }

    public static String getUserEmail(Activity activity) {
        AccountManager manager = AccountManager.get(activity);
        if (ActivityCompat.checkSelfPermission(activity, android.Manifest.permission.GET_ACCOUNTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, new String[]{android.Manifest.permission.GET_ACCOUNTS},Stale.ZEZWOLENIE2);
        }
        Account[] accounts = manager.getAccountsByType("com.google");
        List<String> possibleEmails = new LinkedList<String>();

        for (Account account : accounts) {
            // TODO: Check possibleEmail against an email regex or treat
            // account.name as an email address only for certain account.type values.
            possibleEmails.add(account.name);
        }

        if (!possibleEmails.isEmpty() && possibleEmails.get(0) != null) {
            return possibleEmails.get(0);
        }
        return null;
    }

    public static String getID(Activity activity){
        return Settings.Secure.getString(activity.getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
    }

}
