package tridoo.sigma;

import android.graphics.Point;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Stale {
    public static final int GRANICA_6=6000;
    public static final int GRANICA_UDOSTEPNIENIA_ARCADE=1000;
    public static final int GRANICA_UDOSTEPNIENIA_TIMER=100;
    public static final int PKT_BONUS_1=200;
    public static final int PKT_BONUS_2=250;
    public static final int PKT_BONUS_3=450;
    public static final int PKT_BONUS_4=550;
    public static final int ZEZWOLENIE = 777;
    public static final int ZEZWOLENIE2 = 778;
    public static final int ILE_NA_STARCIE=5;
    public static final int CZAS_TIMERA=60;

    public static final List<Point> wspolrzedneSasiadow = Arrays.asList(
            new Point(-1,0),
            new Point(1,0),
            new Point(0,-1),
            new Point(0,1)
    );

    public static final HashMap<Integer,Class> mapaAktywnosci;
    static {
        mapaAktywnosci=new HashMap<>();
        mapaAktywnosci.put(R.id.btnHelp,HelpActivity.class);
        mapaAktywnosci.put(R.id.btnArcade5,GraArcadeActivity.class);
        mapaAktywnosci.put(R.id.btnTime5,GraTimerActivity.class);
        mapaAktywnosci.put(R.id.btnArcadeLocal5,WynikiLokalneActivity.class);
        mapaAktywnosci.put(R.id.btnArcadeGlobal5,WynikiGlobalneActivity.class);
        mapaAktywnosci.put(R.id.btnTimeLocal5,WynikiLokalneActivity.class);
        mapaAktywnosci.put(R.id.btnTimeGlobal5,WynikiGlobalneActivity.class);

        mapaAktywnosci.put(R.id.btnArcade6,GraArcadeActivity.class);
        mapaAktywnosci.put(R.id.btnTime6,GraTimerActivity.class);
        mapaAktywnosci.put(R.id.btnArcadeLocal6,WynikiLokalneActivity.class);
        mapaAktywnosci.put(R.id.btnArcadeGlobal6,WynikiGlobalneActivity.class);
        mapaAktywnosci.put(R.id.btnTimeLocal6,WynikiLokalneActivity.class);
        mapaAktywnosci.put(R.id.btnTimeGlobal6,WynikiGlobalneActivity.class);
    }

    public static final List<Integer> listaPrzyciskowRozmiar5;
    static {
        listaPrzyciskowRozmiar5 =new ArrayList<>();
        listaPrzyciskowRozmiar5.add(R.id.btnArcade5);
        listaPrzyciskowRozmiar5.add(R.id.btnTime5);
        listaPrzyciskowRozmiar5.add(R.id.btnArcadeLocal5);
        listaPrzyciskowRozmiar5.add(R.id.btnArcadeGlobal5);
        listaPrzyciskowRozmiar5.add(R.id.btnTimeLocal5);
        listaPrzyciskowRozmiar5.add(R.id.btnTimeGlobal5);
    }

    public static final List<Integer> listaPrzyciskowRozmiar6;
    static{
        listaPrzyciskowRozmiar6 =new ArrayList<>();
        listaPrzyciskowRozmiar6.add(R.id.btnArcade6);
        listaPrzyciskowRozmiar6.add(R.id.btnTime6);
        listaPrzyciskowRozmiar6.add(R.id.btnArcadeLocal6);
        listaPrzyciskowRozmiar6.add(R.id.btnTimeLocal6);
        listaPrzyciskowRozmiar6.add(R.id.btnArcadeGlobal6);
        listaPrzyciskowRozmiar6.add(R.id.btnTimeGlobal6);
    }

    public static final List<Integer> listaTimer;
    static{
        listaTimer=new ArrayList<>();
        listaTimer.add(R.id.btnTime5);
        listaTimer.add(R.id.btnTimeLocal5);
        listaTimer.add(R.id.btnTimeGlobal5);
        listaTimer.add(R.id.btnTime6);
        listaTimer.add(R.id.btnTimeLocal6);
        listaTimer.add(R.id.btnTimeGlobal6);
    }

    public static final HashMap<Integer, Integer> mapaRozmiaruId;
    static{
        mapaRozmiaruId=new HashMap<>();
        mapaRozmiaruId.put(5,R.mipmap.size5);
        mapaRozmiaruId.put(6,R.mipmap.size6);
    }

    public static final HashMap<Integer, Integer> mapaClockId;
    static{
        mapaClockId=new HashMap<>();
        mapaClockId.put(5,R.mipmap.clock5);
        mapaClockId.put(6,R.mipmap.clock6);
    }

    public static final HashMap<Integer, Integer> mapaLokalneWynikiId;
    static{
        mapaLokalneWynikiId=new HashMap<>();
        mapaLokalneWynikiId.put(5,R.mipmap.local5);
        mapaLokalneWynikiId.put(6,R.mipmap.local6);
    }

    public static final HashMap<Integer, Integer> mapaGlobalneynikiId;
    static{
        mapaGlobalneynikiId=new HashMap<>();
        mapaGlobalneynikiId.put(5,R.mipmap.global5);
        mapaGlobalneynikiId.put(6,R.mipmap.global6);
    }


}
