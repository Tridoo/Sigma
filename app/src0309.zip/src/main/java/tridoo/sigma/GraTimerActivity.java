package tridoo.sigma;

import android.content.ClipData;
import android.graphics.Color;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import java.util.Locale;


public class GraTimerActivity extends GraActivity {
    boolean isCzyCzasAktywny, isCzyKoniecGry;
    TextView czasPozostaly;
    ProgressBar progressBar;
    TextSwitcher czasDodatkowy;
    Stoper stoper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        czyTimer=true;
        kontrolerEkranuGry.getZrodlo().setOnTouchListener(new ZrodloTouchListener());
        nowaGra();
    }

    @Override
    protected void wypelnijNaglowek() {
        ((LinearLayout)findViewById(R.id.lay_pkt)).setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT,3f));

        LinearLayout naglowek=(LinearLayout)findViewById(R.id.lay_naglowek);
        naglowek.removeViews(1,4);//bonusy

        LinearLayout layProgres=new LinearLayout(context);
        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT,1f);
        layParams.setMargins(10,5,20,5);
        layProgres.setLayoutParams(layParams);
        layProgres.setOrientation(LinearLayout.VERTICAL);

        LinearLayout layCzas=new LinearLayout(context);
        layCzas.setLayoutParams(layParams);
        layCzas.setOrientation(LinearLayout.HORIZONTAL);

        progressBar=new ProgressBar(context,    null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(Stale.CZAS_TIMERA);

        czasPozostaly=new TextView(context);
        czasPozostaly.setTextSize(getResources().getDimension(R.dimen.txt_2));
        czasPozostaly.setTextColor(Color.BLACK);
        czasPozostaly.setGravity(Gravity.START);
        czasPozostaly.setLayoutParams(layParams);

        czasDodatkowy=new TextSwitcher(context);
        czasDodatkowy.setFactory(mFactory);
        czasDodatkowy.setCurrentText(String.valueOf(""));
        czasDodatkowy.setLayoutParams( new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT,2f));
        dodajAnimacjeCzasuDodatkowego();

        layCzas.addView(czasDodatkowy);
        layCzas.addView(czasPozostaly);
        layProgres.addView(layCzas);
        layProgres.addView(progressBar);
        naglowek.addView(layProgres);
    }


    protected void nowaGra(){
        super.nowaGra();
        progressBar.setProgress(0);
        czasPozostaly.setText(String.format(Locale.US,"%.2f", (float) Stale.CZAS_TIMERA));
        isCzyCzasAktywny =false;
        isCzyKoniecGry =false;
        stoper=new Stoper(Stale.CZAS_TIMERA*1000, 50,czasPozostaly,progressBar,this);
    }

    @Override
    protected void koniecGry(){
        super.koniecGry();
        stoper.cancel();
        isCzyKoniecGry =true;
    }

    @Override
    protected boolean czyKoniecGry() {
        return (isCzyKoniecGry || super.czyKoniecGry());
    }

    protected void dodajLiseneryKafelka(Kafelek kafelek){
        kafelek.setOnTouchListener(new TouchListenerKafelka());
        kafelek.setOnDragListener(new DragListenerKafelka());
    }

    @Override
    int podajGraniceUdostepniania() {
        return Stale.GRANICA_UDOSTEPNIENIA_TIMER;
    }

    @Override
    protected void dodajCzas(int ile) {
        czasDodatkowy.setText("+" + ile);
        stoper.cancel();
        long czas = (long) (Float.valueOf(czasPozostaly.getText().toString()) * 1000);
        stoper = new Stoper(czas + ile * 1000, 50, czasPozostaly, progressBar, this);
        stoper.start();
    }

    @Override
    protected void stoperPause() {
        stoper.cancel();
        isCzyCzasAktywny =false;
    }

    @Override
    protected void stoperUnpause() {
        stoper=new Stoper((long)(Float.valueOf(czasPozostaly.getText().toString())*1000), 50,czasPozostaly,progressBar,this);
        stoper.start();
        isCzyCzasAktywny =true;
    }

    private final class DragListenerKafelka implements View.OnDragListener {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            if (isCzyKoniecGry) return true;
            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    break;
                case DragEvent.ACTION_DRAG_ENTERED:
                    if (((TextView) v).getText().length()==3) kontrolerEkranuGry.ustawKolor((TextView) v,-1);
                    break;
                case DragEvent.ACTION_DRAG_EXITED:
                    if (((TextView) v).getText().length()==3) kontrolerEkranuGry.ustawKolor((TextView) v,0);
                    break;
                case DragEvent.ACTION_DROP:
                    if (!isCzyCzasAktywny) {
                        isCzyCzasAktywny =true;
                        stoper.start();
                    }
                    View view = (View) event.getLocalState();
                    Kafelek kafelek = (Kafelek) v;
                    if (view instanceof TextView) {
                        TextView tv = (TextView) view;
                        if (kafelek.getText().length() == 3) {
                            sprawdzKafelek(kafelek, tv.getText().toString());
                            kontrolerEkranuGry.ustawZrodlo(Utils.losujLiczbe(maxLiczba));
                        }
                    }
                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                default:
                    break;
            }
            return true;
        }
    }

    private final class TouchListenerKafelka implements  View.OnTouchListener{
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (isCzyKoniecGry) return true;
            if (!isCzyCzasAktywny) {
                isCzyCzasAktywny =true;
                stoper.start();
            }

            if (event.getAction() == MotionEvent.ACTION_DOWN){
                Kafelek kafelek=(Kafelek)v;
                if (kafelek.getText().length() == 3) {
                    String liczba = kontrolerEkranuGry.getZrodlo().getText().toString();
                    kafelek.setText(liczba);
                    sprawdzKafelek(kafelek, liczba);
                    kontrolerEkranuGry.ustawZrodlo(Utils.losujLiczbe(maxLiczba));
                    return true;
                }
            }
            return false;
        }
    }

    private final class ZrodloTouchListener implements View.OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                view.startDrag(data, shadowBuilder, view, 0);
                return true;
            } else {
                return false;
            }
        }
    }

    private ViewSwitcher.ViewFactory mFactory = new ViewSwitcher.ViewFactory() {
        @Override
        public View makeView() {
            TextView t = new TextView(context);
            t.setGravity(Gravity.CENTER |Gravity.BOTTOM);
            t.setTextColor(Color.GREEN);
            t.setTextSize(getResources().getDimension(R.dimen.txt_2));
            return t;
        }
    };

    private void dodajAnimacjeCzasuDodatkowego(){
        Animation blink = AnimationUtils.loadAnimation(this, R.anim.blink);
        blink.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {                            }
            @Override
            public void onAnimationEnd(Animation animation) {  czasDodatkowy.setCurrentText("");          }
            @Override
            public void onAnimationRepeat(Animation animation) {            }
        });

        czasDodatkowy.setInAnimation(blink);
    }

    @Override
    void operacjeDodatkowePunktow(int pkt) {    }

    @Override
    void operacjaDodatkoweBonusow() {}
}
