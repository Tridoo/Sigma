package tridoo.sigma;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.FacebookSdk;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareOpenGraphAction;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.ShareOpenGraphObject;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.widget.ShareDialog;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

abstract class GraActivity extends Activity {
    private int maxWynikGlobalny;
    private String plikFTP;
    private String email;
    private String xywa;

    protected int maxLiczba;
    private int rozmiarPola;
    private int tablicaWartosci[][];
    private boolean sprawdzonePozycje[][];
    protected boolean czyTimer;
    private int punkty;
    private List<Integer> paletaKolorow;
    private TextView licznikPKT;

    protected Context context;
    protected KontrolerEkranuGry kontrolerEkranuGry;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gra);
        kontrolerEkranuGry=new KontrolerEkranuGry(this);

        context=getApplicationContext();
        wypelnijNaglowek();
        licznikPKT=(TextView)findViewById(R.id.tv_pkt);

        rozmiarPola=getIntent().getIntExtra("poziom",1);
        paletaKolorow = Utils.podajPaleteTel(rozmiarPola);

        kontrolerEkranuGry.dodajPusteKafelki(rozmiarPola);
        kontrolerEkranuGry.ustawPrzyciskiKonca();
        pobierzDaneFtp(); //zawiera update xywy
    }

    @Override
    protected void onResume() {
        super.onResume();
        //uruchomReklamy();
    }

    @Override
    public void onBackPressed() {
        if(punkty==0 || czyKoniecGry()) {
            super.onBackPressed();
            return;
        }
        stoperPause();

        Dialog dialog;
        final String[] items = {"Save Score"};
        final boolean[] selectedItems={true};

        final ArrayList<Integer> itemsSelected = new ArrayList<>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("End the game?");
        builder.setMultiChoiceItems(items, selectedItems,
                new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId,
                                        boolean isSelected) {
                        if (isSelected) {
                            itemsSelected.add(selectedItemId);
                        } else if (itemsSelected.contains(selectedItemId)) {
                            itemsSelected.remove(Integer.valueOf(selectedItemId));
                        }
                    }
                })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        if (((AlertDialog) dialog).getListView().getCheckedItemPositions().get(0)) {
                            zapiszWynik(punkty,czyTimer);
                        }
                        GraActivity.super.onBackPressed();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                stoperUnpause();
                            }
                        }
                );
        dialog = builder.create();
        dialog.show();
    }

    private void uruchomReklamy()    {
        AdView mAdView = (AdView) findViewById(R.id.banerGra);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    protected void nowaGra(){
        punkty=0;
        maxLiczba=1;
        tablicaWartosci=new int[rozmiarPola+2][rozmiarPola+2];
        sprawdzonePozycje=new boolean[rozmiarPola+2][rozmiarPola+2];
        kontrolerEkranuGry.ustawZrodlo(1);
        kontrolerEkranuGry.dodajPierwszeKafeleki(rozmiarPola);
        kontrolerEkranuGry.ustawWidoczoscKonca(false);
        licznikPKT.setText(String.valueOf(0));
    }

    public int podajKolor(int pkt){
        int rozmiar=paletaKolorow.size();
        if (pkt>=rozmiar) return paletaKolorow.get(rozmiar-1);
        else return paletaKolorow.get(pkt);
    }

    protected void sprawdzKafelek(Kafelek kafelek, String aWartosc) {
        boolean czyBylyZmiany = false;
        int pWartosc = Integer.valueOf(aWartosc);
        int x=kafelek.getPosInGrid()[0];
        int y=kafelek.getPosInGrid()[1];
        tablicaWartosci[x][y] = pWartosc;
        kontrolerEkranuGry.ustawKafelek(kafelek,pWartosc);
        Set<Kafelek> pListaOdpowiednichSasiadow = podajListeOdpowiednichSasiadow(kafelek);

        if (pListaOdpowiednichSasiadow.size() > 2) {
            if (pWartosc == maxLiczba) maxLiczba++;
            kontrolerEkranuGry.czyscKafeki(pListaOdpowiednichSasiadow);
            tablicaWartosci[x][y] = pWartosc + 1;
            kontrolerEkranuGry.ustawKafelek(kafelek,pWartosc+1);
            int pkt = Utils.ilePunktowDodac(pWartosc, pListaOdpowiednichSasiadow.size());
            dodajPKT(pkt);
            czyBylyZmiany = true;
            operacjeDodatkowePunktow(pkt);
            dodajCzas(pWartosc);
        }
        if (czyKoniecGry()) {
            koniecGry();
        } else {
            czyscSprawdzonePozycje();
            if (czyBylyZmiany) sprawdzKafelek(kafelek, String.valueOf(pWartosc + 1));
            operacjaDodatkoweBonusow();
        }
    }

    protected void koniecGry(){
        kontrolerEkranuGry.ustawWidoczoscKonca(true);
        if(punkty>0)zapiszWynik(punkty,czyTimer); //rowniez globalny
        udostepnijWynik(punkty);
    }

    public Set<Kafelek> podajListeOdpowiednichSasiadow(Kafelek aKafelek){
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];
        int pWartosc=tablicaWartosci[pX][pY];

        sprawdzonePozycje[pX][pY]=true;
        Set<Kafelek> listaDoZamiany=new HashSet<>();
        listaDoZamiany.add(aKafelek);
        List<Kafelek> listaDoSprawdzenia=new ArrayList<>();
        List<Kafelek> tmp=podajFiltrowanaListeSasiadow(aKafelek, pWartosc);
        listaDoZamiany.addAll(tmp);
        listaDoSprawdzenia.addAll(tmp);

        ListIterator<Kafelek> iterator = listaDoSprawdzenia.listIterator();
        while (iterator.hasNext()) {
            Kafelek pKafelek = iterator.next();
            tmp=podajFiltrowanaListeSasiadow(pKafelek, pWartosc);
            if (!tmp.isEmpty()){
                listaDoZamiany.addAll(tmp);
                for (Kafelek aSasiad: tmp){
                    iterator.add(aSasiad);
                    iterator.previous();
                }
            }
        }
        return listaDoZamiany;
    }

    private List<Kafelek> podajFiltrowanaListeSasiadow(Kafelek aKafelek, int aWartosc){
        List<Kafelek> pListaSasiadow=new ArrayList<>();
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];

        for (Point wspolrzedna : Stale.wspolrzedneSasiadow) {
            if (czyDodacSasiada(pX-wspolrzedna.x, pY-wspolrzedna.y, aWartosc))
                pListaSasiadow.add(znajdzKafelek(pX-wspolrzedna.x, pY-wspolrzedna.y));
        }
        sprawdzonePozycje[pX][pY]=true;
        return pListaSasiadow;
    }

    private boolean czyDodacSasiada(int x, int y, int wartosc){
        return (!sprawdzonePozycje[x][y] && tablicaWartosci[x][y]==wartosc);
    }

    @Nullable
    public Kafelek znajdzKafelek(int x, int y){
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i = 0; i < ileKafelkow; i++) {
            Kafelek pKafelek = (Kafelek) gridLayout.getChildAt(i);
            if ((pKafelek.getPosInGrid()[0]==x) && (pKafelek.getPosInGrid()[1]==y)) return pKafelek;
        }
        return null;
    }

    public void czyscSprawdzonePozycje() {
        sprawdzonePozycje=new boolean[rozmiarPola+2][rozmiarPola+2];
    }

    private void dodajPKT(int nowePKT){
        punkty+=nowePKT;
        licznikPKT.setText(String.valueOf(punkty));
    }

    protected boolean czyKoniecGry() {
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i = 0; i < ileKafelkow; i++) {
            Kafelek pKafelek = (Kafelek) gridLayout.getChildAt(i);
            if (pKafelek.getText().length() == 3) return false;
        }
        return true;
    }

    private void zapiszWynik(int pkt, boolean isCzyTimer){
        DAO dao=new DAO(context);
        dao.dodajWynik(pkt,rozmiarPola,isCzyTimer);
        if (pkt>Stale.GRANICA_6) dao.ustawDostepny6();
        if (pkt>maxWynikGlobalny)  {
            try {
                String progres=new FtpTask(this).execute(podajNazwePlikuFTP(),podajEmail(),podajXywe(),String.valueOf(pkt)).get();
                //progres tylko na czekanie przed zamknieciem
            } catch (Exception e) {
                e.printStackTrace();
            }
            maxWynikGlobalny=pkt;
        }
    }

    private void udostepnijWynik(final int pkt) {
        ImageView share=(ImageView)findViewById(R.id.btnShare);
        if (pkt >= podajGraniceUdostepniania()) {
            share.setImageResource(R.mipmap.share_on);
            share.setOnClickListener((new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    wyslijWynik(pkt);
                    //udostepnijFB(pkt);
                }
            }));
        } else {
            share.setImageResource(R.mipmap.share_off);
            share.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "Need " + podajGraniceUdostepniania() + " points", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private void wyslijWynik(int pkt){//todo refaktor nazw
        if (ContextCompat.checkSelfPermission(context,  Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            udostepnij(pkt);
            return;
        }

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            Toast.makeText(context, "NEED PERMISSION", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Stale.ZEZWOLENIE);
        }
    }

    private void udostepnij(int pkt){ // udostepnianie ogolne
        int id_bmp_wynikow;
        id_bmp_wynikow = rozmiarPola == 5 ? R.mipmap.wynik_5 : R.mipmap.wynik_6;

        Bitmap icon = BitmapFactory.decodeResource(getApplicationContext().getResources(), id_bmp_wynikow);

        Bitmap workingBitmap = Bitmap.createBitmap(icon);
        Bitmap mutableBitmap = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(mutableBitmap);
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setAntiAlias(true);
        paint.setTextSize(canvas.getHeight()/10);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(String.valueOf(pkt), (canvas.getWidth() / 2f) , (canvas.getHeight() / 1.53f), paint);

        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("image/jpeg");

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "Game score");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        OutputStream outstream;
        try {
            outstream = getContentResolver().openOutputStream(uri);
            mutableBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outstream);
            outstream.close();
        } catch (Exception e) {
            System.err.println(e.toString());
        }

        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.putExtra(Intent.EXTRA_TEXT, "New score: "+ pkt+" points");
        startActivity(Intent.createChooser(share, "Share Image"));
    }

    public void wyjscie(){
        finish();
    }

    private void udostepnijFB(int punkty) {
        //FacebookSdk.sdkInitialize(this);
        if (!ShareDialog.canShow(ShareLinkContent.class)) return;
        FacebookSdk.setApplicationId(getString(R.string.facebook_app_id));
        //CallbackManager callbackManager = CallbackManager.Factory.create();
        //ShareDialog shareDialog = new ShareDialog(this);
        //ShareLinkContent linkContent = new ShareLinkContent.Builder()
                        //.setContentTitle("Sigma new score: " + punkty)
                        //.setContentDescription("desc")
                        //.setImageUrl(Uri.parse("android.resource:tridoo.sigma" + idBmp))
//                        .setContentUrl(Uri.parse(getString(R.string.link))).build();
        //shareDialog.show(linkContent);

        ShareOpenGraphObject object = new ShareOpenGraphObject.Builder()
                .putString("og:type", "books.book")
                .putString("og:title", "A Game of Thrones")
                .putString("og:description", "In the frozen wastes to the north of Winterfell, sinister and supernatural forces are mustering.")
                .putString("books:isbn", "0-553-57340-3")
                .build();

        SharePhoto photo = new SharePhoto.Builder()
                .setBitmap(BitmapFactory.decodeResource(getApplicationContext().getResources(), R.mipmap.wynik_5))
                .setUserGenerated(true)
                .build();

        ShareOpenGraphAction action = new ShareOpenGraphAction.Builder()
                .setActionType("books.reads")
                .putObject("book", object)
                .putPhoto("image", photo)
                .build();


        ShareOpenGraphContent content = new ShareOpenGraphContent.Builder()
                .setPreviewPropertyName("fitness:course")
                .setAction(action)
                .build();

        ShareDialog.show(this, content);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,  String permissions[], int[] grantResults) {
        switch (requestCode) {
            case Stale.ZEZWOLENIE: {
                if (grantResults.length > 0  && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    udostepnij(punkty);
                } else {
                    // brak uprawnien
                }
                return;
            }
        }
    }

    public void setMaxWynikGlobalny(int maxWynikGlobalny) {
        this.maxWynikGlobalny = maxWynikGlobalny;
    }

    public int[][] getTablicaWartosci() {
        return tablicaWartosci;
    }

    public void pobierzDaneFtp(){ //wynik ustawiany w ftp onPostExecute
        plikFTP=podajNazwePlikuFTP();
        xywa=podajXywe();
        email=podajEmail();
        new FtpTask(this).execute(plikFTP,podajEmail(),xywa);
    }

    private String podajNazwePlikuFTP() {
        if (plikFTP!=null) return plikFTP;
        String nazwa = "wyniki_";
        int poziom = getIntent().getIntExtra("poziom", 1);
        boolean czyTimer = getIntent().getBooleanExtra("czyTimer", false);
        nazwa += poziom == 5 ? "5_" : "6_";
        nazwa += czyTimer ? "t" : "a";
        return nazwa+=".txt";
    }

    private String podajXywe(){
        if (xywa!=null) return xywa;
        String nick=getIntent().getStringExtra("xywa");
        if (nick==null) nick = getIntent().getStringExtra("nowaXywa");
        return nick;
    }

    private String podajEmail(){
        if (email!=null) return email;
        return getIntent().getStringExtra("email");
    }

    abstract void wypelnijNaglowek();

    abstract void stoperPause();

    abstract void stoperUnpause();

    abstract void operacjeDodatkowePunktow(int pkt);

    abstract void operacjaDodatkoweBonusow();

    abstract   void dodajCzas(int ile);

    abstract protected void dodajLiseneryKafelka(Kafelek kafelek);

    abstract int podajGraniceUdostepniania();

}