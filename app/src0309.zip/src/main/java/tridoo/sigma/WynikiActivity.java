package tridoo.sigma;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public abstract class WynikiActivity extends Activity {
    private int poziom;
    boolean czyTimer;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wyniki);
        poziom=getIntent().getIntExtra("poziom",1);
        czyTimer = getIntent().getBooleanExtra("czyTimer", false);
        generujNaglowek();

        //uruchomReklamy();
    }

    private void uruchomReklamy(){
        AdView mAdView = (AdView) findViewById(R.id.banerWyniki);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }


    protected void generujNaglowek(){
        ((ImageView)findViewById(R.id.ivSize)).setImageDrawable(getResources().getDrawable(Stale.mapaRozmiaruId.get(poziom)));
    }

    public int getPoziom() {
        return poziom;
    }

    public void setPoziom(int poziom) {
        this.poziom = poziom;
    }

}
