package tridoo.sigma;


import android.content.ClipData;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GraArcadeActivity extends GraActivity {
    int pktNaBonus;
    Bonus.Typ wlaczonyBonus;
    List<Bonus> listaBonusow;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        listaBonusow=podajListeBonusow();
        ustawTouchLiseneryBonusow();

        nowaGra();
    }

    @Override
    protected void onResume() {
        ustawProgresBary();
        super.onResume();
    }

    @Override
    protected void nowaGra() {
        pktNaBonus=0;
        wlaczonyBonus=null;
        ustawProgresBary();
        super.nowaGra();
    }


    private List<Bonus> podajListeBonusow(){
        List<Bonus> listaBonusow=new ArrayList<>();

        Bonus kostka=new Bonus();
        kostka.setTyp(Bonus.Typ.NowaLiczba);
        kostka.setIlePKT(Stale.PKT_BONUS_1);
        kostka.setImg((ImageView)findViewById(R.id.iv_bonus1));
        kostka.setIdImgDisable(R.mipmap.kostka_disable);
        kostka.setIdImgOn(R.mipmap.kostka_on);
        kostka.setIdImgOff(R.mipmap.kostka_off);
        kostka.setProgress((ProgressBar)findViewById(R.id.progressBar1));
        kostka.setKrotnosc((TextView)findViewById(R.id.px1));
        listaBonusow.add(kostka);

        Bonus bomba=new Bonus();
        bomba.setTyp(Bonus.Typ.Bomba);
        bomba.setIlePKT(Stale.PKT_BONUS_2);
        bomba.setImg((ImageView)findViewById(R.id.iv_bonus2));
        bomba.setIdImgDisable(R.mipmap.bomb_disable);
        bomba.setIdImgOn(R.mipmap.bomb_on);
        bomba.setIdImgOff(R.mipmap.bomb_off);
        bomba.setProgress((ProgressBar)findViewById(R.id.progressBar2));
        bomba.setKrotnosc((TextView)findViewById(R.id.px2));
        listaBonusow.add(bomba);

        Bonus minus=new Bonus();
        minus.setTyp(Bonus.Typ.Minus);
        minus.setIlePKT(Stale.PKT_BONUS_3);
        minus.setImg((ImageView)findViewById(R.id.iv_bonus3));
        minus.setIdImgDisable(R.mipmap.minus_disable);
        minus.setIdImgOn(R.mipmap.minus_on);
        minus.setIdImgOff(R.mipmap.minus_off);
        minus.setProgress((ProgressBar)findViewById(R.id.progressBar3));
        minus.setKrotnosc((TextView)findViewById(R.id.px3));
        listaBonusow.add(minus);

        Bonus plus=new Bonus();
        plus.setTyp(Bonus.Typ.Plus);
        plus.setIlePKT(Stale.PKT_BONUS_4);
        plus.setImg((ImageView)findViewById(R.id.iv_bonus4));
        plus.setIdImgDisable(R.mipmap.plus_disable);
        plus.setIdImgOn(R.mipmap.plus_on);
        plus.setIdImgOff(R.mipmap.plus_off);
        plus.setProgress((ProgressBar)findViewById(R.id.progressBar4));
        plus.setKrotnosc((TextView)findViewById(R.id.px4));
        listaBonusow.add(plus);
        return listaBonusow;
    }

    private void ustawProgresBary(){
        for(Bonus bonus:listaBonusow){
            int progres=(pktNaBonus*100)/bonus.getIlePKT();
            bonus.getProgress().setProgress(progres);
            bonus.getKrotnosc().setText(progres > 99 ? String.valueOf((int) (progres / 100)) : null);
        }
    }

    private void ustawTouchLiseneryBonusow(){
        kontrolerEkranuGry.getZrodlo().setOnTouchListener(new BonusTouchListener());
        for (Bonus pBonus:listaBonusow){
            pBonus.getImg().setOnTouchListener(new BonusTouchListener());
        }
    }

    protected void dodajLiseneryKafelka(Kafelek kafelek){
        kafelek.setOnTouchListener(new TouchListenerKafelka());
        kafelek.setOnDragListener(new DragListenerKafelka());
    }

    @Override
    protected void operacjeDodatkowePunktow(int pkt) {
        pktNaBonus += pkt;
        animujIkonyBonusow(pkt);
    }

    @Override
    protected void operacjaDodatkoweBonusow() {
        sprawdzicDostepneBonusy();
        ustawProgresBary();
    }

    private void animujIkonyBonusow(int pkt){
        int pktPrzed=pktNaBonus-pkt;
        for (Bonus pBonus:listaBonusow){
            if (pBonus.getIlePKT()<=pktNaBonus && pBonus.getIlePKT()>pktPrzed) {
                Animation animZoom = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom);
                pBonus.getImg().startAnimation(animZoom);
            }
        }
    }

    private void ustawIkoneBonusa(Bonus.Typ typ){
        sprawdzicDostepneBonusy();
        if (typ!=null) {
            for(Bonus bonus:listaBonusow) {
                if (bonus.getTyp()==typ) bonus.getImg().setImageDrawable(getResources().getDrawable(bonus.getIdImgOn()));
            }
        }
    }
    private boolean czyBonusAktywny(ImageView view){
        for (Bonus pBonus:listaBonusow){
            if (pBonus.getImg().getId()==view.getId()){
                return pBonus.getIlePKT() < pktNaBonus;
            }
        }
        return false;
    }

    private Bonus.Typ podajBonusPrzeciagniety(ImageView iv){
        for (Bonus bonus:listaBonusow){
            if(bonus.getImg().getId()==iv.getId()) return bonus.getTyp();
        }
        return null;
    }

    private void uruchomBonus(Kafelek kafelek) {
        if (wlaczonyBonus==null) return;

        int aktualnaLiczba=0;
        String txt=kafelek.getText().toString();
        if (!txt.equals("   ")) aktualnaLiczba=Integer.valueOf(txt);
        int nowaLiczba;

        switch (wlaczonyBonus){
            case NowaLiczba:
                do {
                    nowaLiczba = Utils.losujLiczbe(maxLiczba);
                }while(aktualnaLiczba==nowaLiczba);
                kontrolerEkranuGry.ustawKafelek(kafelek,nowaLiczba);
                sprawdzKafelek(kafelek,String.valueOf(nowaLiczba));
                break;

            case Bomba:
                Set<Kafelek> listaKafelkow = new HashSet<>();
                listaKafelkow.add(kafelek);
                kontrolerEkranuGry.czyscKafeki(listaKafelkow);
                break;

            case Minus:
                if (aktualnaLiczba==0) break;
                nowaLiczba=aktualnaLiczba-1;
                kontrolerEkranuGry.ustawKafelek(kafelek,nowaLiczba);
                if (nowaLiczba!=0) sprawdzKafelek(kafelek,String.valueOf(nowaLiczba));
                break;

            case Plus:
                nowaLiczba=aktualnaLiczba+1;
                if (nowaLiczba>maxLiczba) maxLiczba=nowaLiczba;
                kontrolerEkranuGry.ustawKafelek(kafelek,nowaLiczba);
                sprawdzKafelek(kafelek,String.valueOf(nowaLiczba));
                break;
        }

        for (Bonus bonus:listaBonusow){
            if (bonus.getTyp()==wlaczonyBonus){
                pktNaBonus-=bonus.getIlePKT();
                break;
            }
        }
        if (czyKoniecGry()) koniecGry();
        wlaczonyBonus=null;
        sprawdzicDostepneBonusy();
        ustawProgresBary();
    }

    private void sprawdzicDostepneBonusy() {
        for (Bonus pBonus:listaBonusow){
            if (pktNaBonus>=pBonus.getIlePKT()) pBonus.getImg().setImageDrawable(getResources().getDrawable(pBonus.getIdImgOff()));
            else pBonus.getImg().setImageDrawable(getResources().getDrawable(pBonus.getIdImgDisable()));
        }
    }

    @Override
    protected boolean czyKoniecGry() {
        if (pktNaBonus > Stale.PKT_BONUS_1) return false;
        return super.czyKoniecGry();
    }

    @Override
    int podajGraniceUdostepniania() {
        return Stale.GRANICA_UDOSTEPNIENIA_ARCADE;
    }

    private final class BonusTouchListener implements View.OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                view.startDrag(data, shadowBuilder, view, 0);

                for (int i = 0; i < listaBonusow.size(); i++) {
                    if (view.getId() == listaBonusow.get(i).getImg().getId()) {
                        if (listaBonusow.get(i).getIlePKT() > pktNaBonus) wlaczonyBonus = null;
                        else {
                            if (wlaczonyBonus == null) wlaczonyBonus = listaBonusow.get(i).getTyp();
                            else wlaczonyBonus = null;
                        }
                    }
                }
                ustawIkoneBonusa(wlaczonyBonus);
                return true;
            } else {
                return false;
            }
        }
    }

    private final class TouchListenerKafelka implements  View.OnTouchListener{
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN){
                Kafelek kafelek=(Kafelek)v;
                if (wlaczonyBonus!=null){
                    uruchomBonus(kafelek);
                    ustawIkoneBonusa(wlaczonyBonus);
                    return true;
                }
                if (kafelek.getText().length() == 3) {
                    String liczba = kontrolerEkranuGry.getZrodlo().getText().toString();
                    kafelek.setText(liczba);
                    sprawdzKafelek(kafelek, liczba);
                    kontrolerEkranuGry.ustawZrodlo(Utils.losujLiczbe(maxLiczba));
                    return true;
                }
            }
            return false;
        }
    }

    private final class DragListenerKafelka implements View.OnDragListener {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    break;
                case DragEvent.ACTION_DRAG_ENTERED:
                    if (((TextView) v).getText().length()==3) kontrolerEkranuGry.ustawKolor((TextView) v,-1);
                    break;
                case DragEvent.ACTION_DRAG_EXITED:
                    if (((TextView) v).getText().length()==3) kontrolerEkranuGry.ustawKolor((TextView) v,0);
                    break;
                case DragEvent.ACTION_DROP:
                    View view = (View) event.getLocalState();
                    Kafelek kafelek = (Kafelek) v;
                    if (view instanceof TextView) {
                        TextView tv = (TextView) view;
                        if (kafelek.getText().length() == 3) {
                            sprawdzKafelek(kafelek, tv.getText().toString());
                            kontrolerEkranuGry.ustawZrodlo(Utils.losujLiczbe(maxLiczba));
                        }
                    } else if (view instanceof ImageView){
                        if (czyBonusAktywny((ImageView) view)) {
                            if (wlaczonyBonus==null) wlaczonyBonus=podajBonusPrzeciagniety((ImageView)view);
                            uruchomBonus(kafelek);
                        }
                        else {
                            if (kafelek.getText().toString().equals("   ")) kontrolerEkranuGry.ustawKolor(kafelek,0);
                            else kontrolerEkranuGry.ustawKafelek(kafelek,Integer.valueOf(kafelek.getText().toString()));
                        }
                    }
                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                default:
                    break;
            }
            return true;
        }
    }

    @Override
    void wypelnijNaglowek() {    }

    @Override
    void stoperPause() {    }

    @Override
    void stoperUnpause() {    }

    @Override
    void dodajCzas(int ile) {    }
}
