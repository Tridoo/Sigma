package tridoo.sigma;


import android.os.CountDownTimer;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Stoper extends CountDownTimer {
    private TextView czasPozostaly;
    private ProgressBar progressBar;
    private float sec;
    private GraTimerActivity activity;

    public Stoper(long millisInFuture, long countDownInterval, TextView aCzasPozostaly, ProgressBar aProgressBar, GraTimerActivity aActivity) {
        super(millisInFuture, countDownInterval);
        czasPozostaly=aCzasPozostaly;
        progressBar=aProgressBar;
        activity=aActivity;
    }

    @Override
    public void onTick(long millisUntilFinished) {
        sec=(float)TimeUnit.MILLISECONDS.toMillis(millisUntilFinished)/1000;
        czasPozostaly.setText(String.format(Locale.US,"%.2f",sec));
        progressBar.setProgress(Stale.CZAS_TIMERA-(int)sec);

    }

    @Override
    public void onFinish() {
        czasPozostaly.setText("0.00");
        activity.koniecGry();
    }
}
