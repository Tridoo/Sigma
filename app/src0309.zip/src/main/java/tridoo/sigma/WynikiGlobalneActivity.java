package tridoo.sigma;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;


public class WynikiGlobalneActivity extends WynikiActivity {
    private FtpTask ftpTask;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        findViewById(R.id.progresScore).setVisibility(View.VISIBLE);
        String plik=podajNazwePlikuFTP();
        String nowaXywa=podajNowaXywe();
        ftpTask=new FtpTask(this);

        if( nowaXywa!=null ) {
            ftpTask.execute(plik,podajEmail(),nowaXywa);
        }
        else ftpTask.execute(plik);
    }


    protected void dodajWyniki(HashMap<String, Integer> mapaWynikow) {
        GridLayout tabelaWynikow = (GridLayout) findViewById(R.id.grid);
        tabelaWynikow.setColumnCount(3);
        float rozmiarTxt = getResources().getDimension(R.dimen.txt_1);
        int licznik = 1;

        for (Map.Entry<String, Integer> wynik : mapaWynikow.entrySet()) {
            TextView tvLicznik = new TextView(this);
            tvLicznik.setText(licznik + ".  ");
            tvLicznik.setTextSize(rozmiarTxt);

            TextView tvXywa = new TextView(this);
            tvXywa.setText(wynik.getKey());
            tvXywa.setTextSize(rozmiarTxt);

            TextView tvWynik = new TextView(this);
            tvWynik.setText(String.valueOf(wynik.getValue()));
            tvWynik.setTextSize(rozmiarTxt);
            tvWynik.setPadding((int)rozmiarTxt,(int)(rozmiarTxt*0.5),0,(int)(rozmiarTxt*0.5));

            tvLicznik.setLayoutParams(new GridLayout.LayoutParams(GridLayout.spec(licznik, GridLayout.CENTER), GridLayout.spec(0, GridLayout.END)));
            tvXywa.setLayoutParams(new GridLayout.LayoutParams(GridLayout.spec(licznik, GridLayout.CENTER), GridLayout.spec(1, GridLayout.CENTER)));
            tvWynik.setLayoutParams(new GridLayout.LayoutParams(GridLayout.spec(licznik, GridLayout.CENTER), GridLayout.spec(2, GridLayout.START)));

            tabelaWynikow.addView(tvLicznik);
            tabelaWynikow.addView(tvXywa);
            tabelaWynikow.addView(tvWynik);

            licznik++;
            if (licznik>300) break; //max 350
        }
        findViewById(R.id.progresScore).setVisibility(View.GONE);
    }

    private String podajNazwePlikuFTP() {
        String nazwa = "wyniki_";
        nazwa += getPoziom() == 5 ? "5_" : "6_";
        nazwa += czyTimer ? "t" : "a";
        return nazwa+=".txt";
    }

    private String podajNowaXywe(){
        return getIntent().getStringExtra("nowaXywa");
    }

    private String podajEmail(){
        return getIntent().getStringExtra("email");
    }

    @Override
    protected void generujNaglowek() {
        super.generujNaglowek();
        if (czyTimer) ((ImageView)findViewById(R.id.ivClock)).setImageDrawable(getResources().getDrawable(Stale.mapaClockId.get(getPoziom())));
        ((ImageView)findViewById(R.id.ivMode)).setImageDrawable(getResources().getDrawable(Stale.mapaGlobalneynikiId.get(getPoziom())));
    }

    @Override
    public void onBackPressed() {
        if(!ftpTask.getStatus().equals(AsyncTask.Status.FINISHED)) ftpTask.cancel(true);
        super.onBackPressed();
    }
}