package tridoo.sigma;


import android.view.Gravity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Random;
import java.util.Set;

public class KontrolerEkranuGry {
    private GraActivity activity;
    private TextView zrodlo;

    public KontrolerEkranuGry(GraActivity activity) {
        this.activity = activity;
        zrodlo= (TextView)activity.findViewById(R.id.tv_zrodlo);
    }

    public void dodajPusteKafelki(final int rozmiarPola) {
        final GridLayout gridLayout = (GridLayout) activity.findViewById(R.id.gridLayout);
        gridLayout.removeAllViews();
        gridLayout.setColumnCount(rozmiarPola);
        gridLayout.setRowCount(rozmiarPola);
        for (int i = 0; i < rozmiarPola; i++) {
            for (int j = 0; j < rozmiarPola; j++) {

                Kafelek textView = new Kafelek(activity);
                textView.setBackground(activity.getResources().getDrawable(R.drawable.bg_round));
                textView.setText("   ");
                textView.setTextSize(activity.getResources().getDimension(R.dimen.txt_2));
                textView.setGravity(Gravity.CENTER);
                textView.setPosInGrid(j + 1, i + 1);
                activity.dodajLiseneryKafelka(textView);

                int marginesKafelka = activity.getResources().getDimensionPixelSize(R.dimen.margines_kafelka);
                GridLayout.LayoutParams gridParam = new GridLayout.LayoutParams();
                gridParam.setMargins(marginesKafelka, marginesKafelka, marginesKafelka, marginesKafelka);
                gridParam.setGravity(Gravity.FILL);
                gridLayout.addView(textView, gridParam);
            }
        }

        gridLayout.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        int marginesKafelka = activity.getResources().getDimensionPixelSize(R.dimen.margines_kafelka);
                        int szerokosc = (int) ((gridLayout.getWidth() - 2 * rozmiarPola * marginesKafelka));
                        int wysokosc = (int) ((gridLayout.getHeight() - 2 * rozmiarPola * marginesKafelka));
                        for (int i = 0; i < rozmiarPola * rozmiarPola; i++) {
                            ((Kafelek) gridLayout.getChildAt(i)).setWidth(szerokosc / rozmiarPola);
                            ((Kafelek) gridLayout.getChildAt(i)).setHeight(wysokosc / rozmiarPola);
                        }
                        gridLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }
                });
    }

    public void dodajPierwszeKafeleki(int rozmiarPola){
        Random rnd=new Random();
        int x, y, ile=0;
        Kafelek kafelek;

        do{
            x=rnd.nextInt(rozmiarPola)+1;
            y=rnd.nextInt(rozmiarPola)+1;
            if(activity.getTablicaWartosci()[x][y]==1) continue;
            kafelek=activity.znajdzKafelek(x,y);
            activity.getTablicaWartosci()[x][y]=1;
            if(activity.podajListeOdpowiednichSasiadow(kafelek).size()>1){
                activity.getTablicaWartosci()[x][y]=0;
                activity.czyscSprawdzonePozycje();
                continue;
            }
            ustawKafelek(kafelek,1);
            ile++;
            activity.czyscSprawdzonePozycje();
        }while(ile<Stale.ILE_NA_STARCIE);
    }

    public void ustawKafelek(Kafelek aKafelek, int aWartosc){
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];
        activity.getTablicaWartosci()[pX][pY]=aWartosc;
        if (aWartosc==0)aKafelek.setText("   ");
        else aKafelek.setText(String.valueOf(aWartosc));
        ustawKolor(aKafelek,aWartosc);
    }

    private void czyscWszystkieKafelki(){
        GridLayout gridLayout = (GridLayout) activity.findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i=0; i<ileKafelkow;i++){
            ustawKafelek((Kafelek)gridLayout.getChildAt(i),0);
        }
    }

    public void ustawKolor(TextView kafelek, int pkt){
        kafelek.setBackground(activity.getResources().getDrawable(activity.podajKolor(pkt+1)));
    }

    public void czyscKafeki(Set<Kafelek> aLista){
        for(Kafelek pKafelek:aLista){
            ustawKafelek(pKafelek,0);
        }
    }

    public void ustawZrodlo(int liczba){
        zrodlo.setText(String.valueOf(liczba));
        ustawKolor(zrodlo,liczba);
    }

    public void ustawPrzyciskiKonca(){
        //przycisk udostepniania ustawiany na koncu gry
        ((ImageView)activity.findViewById(R.id.btnExit)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.wyjscie();
            }
        });

        ((ImageView)activity.findViewById(R.id.btnRestart)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ustawWidoczoscKonca(false);
                czyscWszystkieKafelki();
                activity.nowaGra();
            }
        });
    }

    public void ustawWidoczoscKonca(boolean isVisible){
        RelativeLayout lay=(RelativeLayout) activity.findViewById(R.id.layPrzyciskiKoniec);
        lay.setVisibility(isVisible ? View.VISIBLE : View.INVISIBLE);
    }

    public TextView getZrodlo() {
        return zrodlo;
    }
}
