package tridoo.sigma;

import android.app.Activity;
import android.os.AsyncTask;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

public class FtpTask extends AsyncTask<String, Void, String> {
    private Activity activity;
    private String xywa,email, nowaXywa;
    private boolean czyZapis,czyOdczytMax, czyUpdateXywy;
    private int pkt;
    private List<Wynik> listaWynikow;


    public FtpTask(Activity aActivity) {
        activity = aActivity;
    }

    protected String doInBackground(String... args) {
        String url = activity.getString(R.string.ftp_host);
        String dir = activity.getString(R.string.ftp_dir);
        String login = activity.getString(R.string.ftp_login);
        String pass = activity.getString(R.string.ftp_pass);
        listaWynikow=new ArrayList<>();
        String plik = args[0];

        switch (args.length) {
            case 2:
                email = args[1];
                czyOdczytMax = true;
                break;
            case 3:
                email = args[1];
                nowaXywa=args[2];
                czyUpdateXywy=true;
                czyZapis = true;
                if(activity instanceof GraActivity) czyOdczytMax =true;
                break;
            case 4:
                email = args[1];
                xywa = args[2];
                pkt = Integer.valueOf(args[3]);
                czyZapis = true;
                break;
        }

        FTPClient ftp = new FTPClient();
        try {
            ftp.connect(url);
            ftp.login(login, pass);
            ftp.enterLocalPassiveMode(); // important!
            ftp.changeWorkingDirectory(dir);
            ftp.setFileTransferMode(FTP.BINARY_FILE_TYPE);

            InputStream input = ftp.retrieveFileStream(plik);
            if (input != null) {
                BufferedReader buffreader = new BufferedReader(new InputStreamReader(input));
                String line;

                while ((line = buffreader.readLine()) != null) {
                    String[] pola = line.split(";");
                    try {
                        listaWynikow.add(new Wynik(pola[0], pola[1], Integer.valueOf(pola[2])));
                    }
                    catch (ArrayIndexOutOfBoundsException e){
                        //todo odczytac backup jesli odczyt zawiedzie
                    }
                }
                buffreader.close();
                input.close();
            }

            if(czyZapis) {
                ftp.logout(); //glupie ale dziala
                ftp.disconnect();

                ftp.connect(url);
                ftp.login(login, pass);
                ftp.enterLocalPassiveMode(); // important!
                ftp.changeWorkingDirectory(dir);
                ftp.setFileTransferMode(FTP.BINARY_FILE_TYPE);

                String kopia=podajNazwePlikuKopi(plik);;
                boolean rename = ftp.rename(plik, kopia);
                if(czyUpdateXywy) {
                    zmienNick(email, nowaXywa);
                }
                else {
                    dopiszWynik(xywa, email, pkt);
                }
                String wyniki = konwertujListeWynikow();
                InputStream is = new ByteArrayInputStream(wyniki.getBytes());
                boolean result = ftp.storeFile(plik, is);
                is.close();
            }

            ftp.logout();
            ftp.disconnect();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        if (activity instanceof WynikiGlobalneActivity) {
            HashMap<String,Integer> mapaWynikow=new HashMap<>();
            for (Wynik wynik:listaWynikow){
                mapaWynikow.put(wynik.xywa,wynik.pkt);
            }
            ((WynikiGlobalneActivity) activity).dodajWyniki(sortByValues(mapaWynikow));
        }

        if (activity instanceof GraActivity){
            if (czyOdczytMax)((GraActivity) activity).setMaxWynikGlobalny(podajOdczytanyWynikGracza(email));
        }
    }

    private String konwertujListeWynikow(){
        String rezultat="";
        for (Wynik wynik:listaWynikow){
            rezultat+=wynik.xywa+";"+wynik.email+";"+wynik.pkt+"\r\n";
        }
        return rezultat;
    }

    private int podajOdczytanyWynikGracza(String email){
        for (Wynik wynik:listaWynikow){
            if(email.equals(wynik.email)) return wynik.pkt;
        }
        return 0;
    }

    private static HashMap<String,Integer> sortByValues(HashMap<String,Integer> map) {
        List list = new LinkedList<>(map.entrySet());
        // Defined Custom Comparator here
        Collections.sort(list, new Comparator() {
            public int compare(Object o1, Object o2) {
                return ((Comparable) ((Map.Entry) (o2)).getValue())
                        .compareTo(((Map.Entry) (o1)).getValue());
            }
        });
        // Here I am copying the sorted list in HashMap
        // using LinkedHashMap to preserve the insertion order
        HashMap<String,Integer> sortedHashMap = new LinkedHashMap<>();
        for (Iterator it = list.iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            sortedHashMap.put((String)entry.getKey(), (Integer) entry.getValue());
        }
        return sortedHashMap;
    }

    private void dopiszWynik(String xywa, String email, int pkt){
        for (Wynik wynik:listaWynikow){
            if (email.equals(wynik.email)){
                wynik.pkt=pkt;
                return;
            }
        }
        listaWynikow.add(new Wynik(xywa,email,pkt));
    }

    private void zmienNick(String email, String nowaXywa){
        for (Wynik wynik:listaWynikow){
            if(wynik.email.equals(email)) {
                wynik.xywa=nowaXywa;
                return;
            }
        }
    }

    private String podajNazwePlikuKopi(String nazwa){
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+1:00"));
        Date currentLocalTime = cal.getTime();
        DateFormat date = new SimpleDateFormat("yy_MM_dd_HH_mm");
        date.setTimeZone(TimeZone.getTimeZone("GMT+1:00"));

        return nazwa.replace(".txt","_")+ date.format(currentLocalTime)+".txt";
    }

    private class Wynik{
        String xywa;
        String email;
        int pkt;

        public Wynik(String xywa, String email, int pkt) {
            this.xywa = xywa;
            this.email = email;
            this.pkt = pkt;
        }
    }

}