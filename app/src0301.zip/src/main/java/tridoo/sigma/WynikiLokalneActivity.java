package tridoo.sigma;

import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.TextView;

import java.util.Collections;
import java.util.List;


public class WynikiLokalneActivity extends WynikiActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        boolean czyTimer=getIntent().getBooleanExtra("czyTimer",false);
        DAO dao=new DAO(getApplicationContext());
        dodajWyniki(dao.odczytajWyniki(getPoziom(),czyTimer));

    }

    private void dodajWyniki(List<Integer> listaWynikow){
        Collections.reverse(listaWynikow);
        GridLayout tabelaWynikow = (GridLayout) findViewById(R.id.grid);
        tabelaWynikow.setColumnCount(2);
        float rozmiarTxt=getResources().getDimension(R.dimen.rozmiar_small);
        int licznik=1;

        for(Integer wynik:listaWynikow) {
            TextView tvLicznik = new TextView(this);
            tvLicznik.setText(licznik + ".");
            tvLicznik.setTextSize(rozmiarTxt);

            TextView tvWynik = new TextView(this);
            tvWynik.setText(String.valueOf(wynik));
            tvWynik.setTextSize(rozmiarTxt);
            tvWynik.setPadding((int)rozmiarTxt,(int)(rozmiarTxt*0.5),0,(int)(rozmiarTxt*0.5));

            tvLicznik.setLayoutParams(new GridLayout.LayoutParams(GridLayout.spec(licznik, GridLayout.CENTER), GridLayout.spec(0, GridLayout.END)));
            tvWynik.setLayoutParams( new GridLayout.LayoutParams(GridLayout.spec(licznik, GridLayout.CENTER), GridLayout.spec(1, GridLayout.START)));

            tabelaWynikow.addView(tvLicznik);
            tabelaWynikow.addView(tvWynik);

            licznik++;
        }
    }

    @Override
    String podajTytul() {
        return "SCORES";
    }
}
