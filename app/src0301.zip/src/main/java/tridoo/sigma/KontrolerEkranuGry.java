package tridoo.sigma;


import android.app.Activity;

public class KontrolerEkranuGry {
    private Activity activity;

    public KontrolerEkranuGry(Activity activity) {
        this.activity = activity;
    }

    public void dodajPusteKafelki(){}

    public void dodajPierwszeKafelki(){}

}
