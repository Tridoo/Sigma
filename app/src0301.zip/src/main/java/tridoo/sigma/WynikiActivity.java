package tridoo.sigma;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public abstract class WynikiActivity extends Activity {
    private int poziom;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wyniki);
        poziom=getIntent().getIntExtra("poziom",1);
        generujNaglowek();

        //uruchomReklamy();
    }

    private void uruchomReklamy(){
        AdView mAdView = (AdView) findViewById(R.id.banerWyniki);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }


    private void generujNaglowek(){
        ((TextView)findViewById(R.id.tv_tytul)).setText(podajTytul());
        ((ImageView)findViewById(R.id.iv_rozmiar)).setImageDrawable(getResources().getDrawable(podajObrazekRozmiaru()));

    }

    private int podajObrazekRozmiaru(){
        return poziom == 5 ? R.mipmap.rozmiar_5 : R.mipmap.rozmiar_6;
    }


    public int getPoziom() {
        return poziom;
    }

    public void setPoziom(int poziom) {
        this.poziom = poziom;
    }

    abstract String podajTytul();

}
