package tridoo.sigma;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.Layout;
import android.util.Log;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareOpenGraphAction;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.ShareOpenGraphObject;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.widget.ShareButton;
import com.facebook.share.widget.ShareDialog;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.facebook.FacebookSdk;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class GraActivity_old extends Activity {
    int maxLiczba;
    int rozmiarPola;
    int tablicaWartosci[][];
    boolean sprawdzonePozycje[][];
    List<Bonus> listaBonusow;
    int poziom;
    int pktNaBonus;
    int punkty;
    List<Integer> paletaKolorow;
    TextView licznikPKT;
    TextView zrodlo;
    Bonus.Typ wlaczonyBonus;
    //CallbackManager  callbackManager;
    //ShareDialog shareDialog;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        AppEventsLogger.activateApp(getApplication());

        setContentView(R.layout.activity_gra);
        licznikPKT=(TextView)findViewById(R.id.tv_pkt);
        zrodlo= (TextView)findViewById(R.id.tv_zrodlo);

        poziom=getIntent().getIntExtra("poziom",1);
        rozmiarPola = poziom == 6 ? 6 : 5;
        paletaKolorow = Utils.podajPaleteTel(rozmiarPola);

        listaBonusow=podajListeBonusow();
        ustawTouchLisenery(listaBonusow);

        nowaGra();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ustawProgresBary();
        //uruchomReklamy();
    }

    @Override
    public void onBackPressed() {
        if(punkty==0 || czyKoniecGry()) {
            finish();
            return;
        }

        Dialog dialog;
        final String[] items = {"Save Score"};
        final boolean[] selectedItems={true};

        final ArrayList<Integer> itemsSelected = new ArrayList<>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("End the game?");
        builder.setMultiChoiceItems(items, selectedItems,
                new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId,
                                        boolean isSelected) {
                        if (isSelected) {
                            itemsSelected.add(selectedItemId);
                        } else if (itemsSelected.contains(selectedItemId)) {
                            itemsSelected.remove(Integer.valueOf(selectedItemId));
                        }
                    }
                })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        if (((AlertDialog) dialog).getListView().getCheckedItemPositions().get(0)) zapiszWynik(punkty);
                        finish();
                    }
                })
                .setNegativeButton("No", null);
        dialog = builder.create();
        dialog.show();
    }

    private void uruchomReklamy(){
        AdView mAdView = (AdView) findViewById(R.id.banerGra);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    private void nowaGra(){
        pktNaBonus=0;
        punkty=0;
        wlaczonyBonus=null;
        maxLiczba=1;
        tablicaWartosci=new int[rozmiarPola+2][rozmiarPola+2];
        sprawdzonePozycje=new boolean[rozmiarPola+2][rozmiarPola+2];
        dodajPusteKafelki();
        ustawZrodlo(1);
        dodajPierwszeKafeleki();
        ustawProgresBary();
        schowajPrzyciski();
        licznikPKT.setText(String.valueOf(0));
    }

    public List<Bonus> podajListeBonusow(){
        List<Bonus> listaBonusow=new ArrayList<>();

        Bonus kostka=new Bonus();
        kostka.setTyp(Bonus.Typ.NowaLiczba);
        kostka.setIlePKT(Stale.PKT_BONUS_1);
        kostka.setImg((ImageView)findViewById(R.id.iv_bonus1));
        kostka.setIdImgDisable(R.mipmap.kostka_disable);
        kostka.setIdImgOn(R.mipmap.kostka_on);
        kostka.setIdImgOff(R.mipmap.kostka_off);
        kostka.setProgress((ProgressBar)findViewById(R.id.progressBar1));
        kostka.setKrotnosc((TextView)findViewById(R.id.px1));
        listaBonusow.add(kostka);

        Bonus bomba=new Bonus();
        bomba.setTyp(Bonus.Typ.Bomba);
        bomba.setIlePKT(Stale.PKT_BONUS_2);
        bomba.setImg((ImageView)findViewById(R.id.iv_bonus2));
        bomba.setIdImgDisable(R.mipmap.bomb_disable);
        bomba.setIdImgOn(R.mipmap.bomb_on);
        bomba.setIdImgOff(R.mipmap.bomb_off);
        bomba.setProgress((ProgressBar)findViewById(R.id.progressBar2));
        bomba.setKrotnosc((TextView)findViewById(R.id.px2));
        listaBonusow.add(bomba);

        Bonus minus=new Bonus();
        minus.setTyp(Bonus.Typ.Minus);
        minus.setIlePKT(Stale.PKT_BONUS_3);
        minus.setImg((ImageView)findViewById(R.id.iv_bonus3));
        minus.setIdImgDisable(R.mipmap.minus_disable);
        minus.setIdImgOn(R.mipmap.minus_on);
        minus.setIdImgOff(R.mipmap.minus_off);
        minus.setProgress((ProgressBar)findViewById(R.id.progressBar3));
        minus.setKrotnosc((TextView)findViewById(R.id.px3));
        listaBonusow.add(minus);

        Bonus plus=new Bonus();
        plus.setTyp(Bonus.Typ.Plus);
        plus.setIlePKT(Stale.PKT_BONUS_4);
        plus.setImg((ImageView)findViewById(R.id.iv_bonus4));
        plus.setIdImgDisable(R.mipmap.plus_disable);
        plus.setIdImgOn(R.mipmap.plus_on);
        plus.setIdImgOff(R.mipmap.plus_off);
        plus.setProgress((ProgressBar)findViewById(R.id.progressBar4));
        plus.setKrotnosc((TextView)findViewById(R.id.px4));
        listaBonusow.add(plus);
        return listaBonusow;
    }

    private int podajKolor(int pkt){
        int rozmiar=paletaKolorow.size();
        if (pkt>=rozmiar) return paletaKolorow.get(rozmiar-1);
        else return paletaKolorow.get(pkt);
    }

    private void ustawTouchLisenery(List<Bonus> listaBonusow){
        zrodlo.setOnTouchListener(new MyTouchListener());
        for (Bonus pBonus:listaBonusow){
            pBonus.getImg().setOnTouchListener(new MyTouchListener());
        }
    }

    private void dodajPusteKafelki(){
        final GridLayout gridLayout=(GridLayout)findViewById(R.id.gridLayout);
        gridLayout.removeAllViews();
        gridLayout.setColumnCount(rozmiarPola);
        gridLayout.setRowCount(rozmiarPola);
        for (int i = 0; i < rozmiarPola; i++) {
            for (int j = 0; j < rozmiarPola; j++) {

                Kafelek textView = new Kafelek(this);
                textView.setBackground(getResources().getDrawable(R.drawable.bg_round));
                textView.setText("   ");
                textView.setTextSize(getResources().getDimension(R.dimen.rozmiar_small));
                textView.setGravity(Gravity.CENTER);
                textView.setOnDragListener(new MyDragListener());
                textView.setPosInGrid(j+1, i+1);
                textView.setOnTouchListener(new TouchListenerKafelka());

                int marginesKafelka=getResources().getDimensionPixelSize(R.dimen.margines_kafelka);
                GridLayout.LayoutParams gridParam = new GridLayout.LayoutParams();
                gridParam.setMargins(marginesKafelka, marginesKafelka, marginesKafelka, marginesKafelka);
                gridParam.setGravity(Gravity.FILL);
                gridLayout.addView(textView, gridParam);
            }
        }

        gridLayout.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        int marginesKafelka = getResources().getDimensionPixelSize(R.dimen.margines_kafelka);
                        int szerokosc = (int) ((gridLayout.getWidth() - 2 * rozmiarPola * marginesKafelka));
                        int wysokosc = (int) ((gridLayout.getHeight() - 2 * rozmiarPola * marginesKafelka));
                        for (int i = 0; i < rozmiarPola * rozmiarPola; i++) {
                            ((Kafelek) gridLayout.getChildAt(i)).setWidth(szerokosc / rozmiarPola);
                            ((Kafelek) gridLayout.getChildAt(i)).setHeight(wysokosc / rozmiarPola);
                        }
                        gridLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }
                });
    }

    private void ustawZrodlo(int liczba){
        zrodlo.setText(String.valueOf(liczba));
        ustawKolor(zrodlo,liczba);
    }

    private void dodajPierwszeKafeleki(){
        Random rnd=new Random();
        int x, y, ile=0;
        Kafelek kafelek;

        do{
            x=rnd.nextInt(rozmiarPola)+1;
            y=rnd.nextInt(rozmiarPola)+1;
            if(tablicaWartosci[x][y]==1) continue;
            kafelek=znajdzKafelek(x,y);
            tablicaWartosci[x][y]=1;
            if(podajListeOdpowiednichSasiadow(kafelek).size()>1){
                tablicaWartosci[x][y]=0;
                czyscSprawdzonePozycje();
                continue;
            }
            ustawKafelek(kafelek,1);
            ile++;
            czyscSprawdzonePozycje();
        }while(ile<Stale.ILE_NA_STARCIE);
    }

    private final class MyTouchListener implements View.OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                view.startDrag(data, shadowBuilder, view, 0);

                for (int i = 0; i < listaBonusow.size(); i++) {
                    if (view.getId() == listaBonusow.get(i).getImg().getId()) {
                        if (listaBonusow.get(i).getIlePKT() > pktNaBonus) wlaczonyBonus = null;
                        else {
                            if (wlaczonyBonus == null) wlaczonyBonus = listaBonusow.get(i).getTyp();
                            else wlaczonyBonus = null;
                        }
                    }
                }
                ustawIkoneBonusa(wlaczonyBonus);
                return true;
            } else {
                return false;
            }
        }
    }

    private final class TouchListenerKafelka implements  View.OnTouchListener{
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN){
                Kafelek kafelek=(Kafelek)v;
                if (wlaczonyBonus!=null){
                    uruchomBonus(kafelek);
                    ustawIkoneBonusa(wlaczonyBonus);
                    return true;
                }
                if (kafelek.getText().length() == 3) {
//                    udostepnijFB(1);
                    String liczba = zrodlo.getText().toString();
                    kafelek.setText(liczba);
                    sprawdzKafelek(kafelek, liczba);
                    ustawZrodlo(Utils.losujLiczbe(maxLiczba));
                    return true;
                }
            }
            return false;
        }
    }

    private final class MyDragListener implements View.OnDragListener {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    break;
                case DragEvent.ACTION_DRAG_ENTERED:
                    if (((TextView) v).getText().length()==3) ustawKolor((TextView) v,-1);
                    break;
                case DragEvent.ACTION_DRAG_EXITED:
                    if (((TextView) v).getText().length()==3) ustawKolor((TextView) v,0);
                    break;
                case DragEvent.ACTION_DROP:
                    View view = (View) event.getLocalState();
                    Kafelek kafelek = (Kafelek) v;
                    if (view instanceof TextView) {
                        TextView tv = (TextView) view;
                        if (kafelek.getText().length() == 3) {
                            sprawdzKafelek(kafelek, tv.getText().toString());
                            ustawZrodlo(Utils.losujLiczbe(maxLiczba));
                        }
                    } else if (view instanceof ImageView){
                        if (czyBonusAktywny((ImageView) view)) {
                            if (wlaczonyBonus==null) wlaczonyBonus=podajBonusPrzeciagniety((ImageView)view);
                            uruchomBonus(kafelek);
                        }
                        else {
                            if (kafelek.getText().toString().equals("   ")) ustawKolor(kafelek,0);
                            else ustawKafelek(kafelek,Integer.valueOf(kafelek.getText().toString()));
                        }
                    }
                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                default:
                    break;
            }
            return true;
        }
    }

    private Bonus.Typ podajBonusPrzeciagniety(ImageView iv){
        for (Bonus bonus:listaBonusow){
            if(bonus.getImg().getId()==iv.getId()) return bonus.getTyp();
        }
        return null;
    }

    private boolean czyBonusAktywny(ImageView view){
        for (Bonus pBonus:listaBonusow){
            if (pBonus.getImg().getId()==view.getId()){
                return pBonus.getIlePKT() < pktNaBonus;
            }
        }
        return false;
    }

    private void uruchomBonus(Kafelek kafelek) {
        if (wlaczonyBonus==null) return;

        int aktualnaLiczba=0;
        String txt=kafelek.getText().toString();
        if (!txt.equals("   ")) aktualnaLiczba=Integer.valueOf(txt);
        int nowaLiczba;

        switch (wlaczonyBonus){
            case NowaLiczba:
                do {
                    nowaLiczba = Utils.losujLiczbe(maxLiczba);
                }while(aktualnaLiczba==nowaLiczba);
                ustawKafelek(kafelek,nowaLiczba);
                sprawdzKafelek(kafelek,String.valueOf(nowaLiczba));
                break;

            case Bomba:
                Set<Kafelek> listaKafelkow = new HashSet<>();
                listaKafelkow.add(kafelek);
                czyscKafeki(listaKafelkow);
                break;

            case Minus:
                if (aktualnaLiczba==0) break;
                nowaLiczba=aktualnaLiczba-1;
                ustawKafelek(kafelek,nowaLiczba);
                if (nowaLiczba!=0) sprawdzKafelek(kafelek,String.valueOf(nowaLiczba));
                break;

            case Plus:
                nowaLiczba=aktualnaLiczba+1;
                if (nowaLiczba>maxLiczba) maxLiczba=nowaLiczba;
                ustawKafelek(kafelek,nowaLiczba);
                sprawdzKafelek(kafelek,String.valueOf(nowaLiczba));
                break;
        }

        for (Bonus bonus:listaBonusow){
            if (bonus.getTyp()==wlaczonyBonus){
                pktNaBonus-=bonus.getIlePKT();
                break;
            }
        }
        if (czyKoniecGry()) koniecGry();
        wlaczonyBonus=null;
        sprawdzicDostepneBonusy();
        ustawProgresBary();
    }

    private void sprawdzKafelek(Kafelek kafelek, String aWartosc) { //todo refaktor
        boolean czyBylyZmiany = false;
        int pWartosc = Integer.valueOf(aWartosc);
        tablicaWartosci[kafelek.getPosInGrid()[0]][kafelek.getPosInGrid()[1]] = pWartosc;
        ustawKafelek(kafelek,pWartosc);

        Set<Kafelek> pListaOdpowiednichSasiadow = podajListeOdpowiednichSasiadow(kafelek);

        if (pListaOdpowiednichSasiadow.size() > 2) {
            if (pWartosc == maxLiczba) maxLiczba++;
            czyscKafeki(pListaOdpowiednichSasiadow);

            tablicaWartosci[kafelek.getPosInGrid()[0]][kafelek.getPosInGrid()[1]] = pWartosc + 1;
            ustawKafelek(kafelek,pWartosc+1);
            int pkt = Utils.ilePunktowDodac(pWartosc, pListaOdpowiednichSasiadow.size());
            pktNaBonus += pkt;
            dodajPKT(pkt);
            czyBylyZmiany = true;
            animujIkonyBonusow(pkt);
        }
        if (czyKoniecGry()) {
            koniecGry();
        } else {
            czyscSprawdzonePozycje();
            if (czyBylyZmiany) sprawdzKafelek(kafelek, String.valueOf(pWartosc + 1));
            sprawdzicDostepneBonusy();
            ustawProgresBary();
        }
    }

    private void koniecGry(){
        pokazKoniec();
        zapiszWynik(punkty);
        udostepnijWynik(punkty);
        dodajPrzyciskiRestartWyjscie();
    }

    private Set<Kafelek> podajListeOdpowiednichSasiadow(Kafelek aKafelek){
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];
        int pWartosc=tablicaWartosci[pX][pY];

        sprawdzonePozycje[pX][pY]=true;
        Set<Kafelek> listaDoZamiany=new HashSet<>();
        listaDoZamiany.add(aKafelek);
        List<Kafelek> listaDoSprawdzenia=new ArrayList<>();
        List<Kafelek> tmp=podajFiltrowanaListeSasiadow(aKafelek, pWartosc);
        listaDoZamiany.addAll(tmp);
        listaDoSprawdzenia.addAll(tmp);

        ListIterator<Kafelek> iterator = listaDoSprawdzenia.listIterator();
        while (iterator.hasNext()) {
            Kafelek pKafelek = iterator.next();
            tmp=podajFiltrowanaListeSasiadow(pKafelek, pWartosc);
            if (!tmp.isEmpty()){
                listaDoZamiany.addAll(tmp);
                for (Kafelek aSasiad: tmp){
                    iterator.add(aSasiad);
                    iterator.previous();
                }
            }
        }
        return listaDoZamiany;
    }

    private List<Kafelek> podajFiltrowanaListeSasiadow(Kafelek aKafelek, int aWartosc){
        List<Kafelek> pListaSasiadow=new ArrayList<>();
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];

        for (Point wspolrzedna : Stale.wspolrzedneSasiadow) {
            if (czyDodacSasiada(pX-wspolrzedna.x, pY-wspolrzedna.y, aWartosc))
                pListaSasiadow.add(znajdzKafelek(pX-wspolrzedna.x, pY-wspolrzedna.y));
        }
        sprawdzonePozycje[pX][pY]=true;
        return pListaSasiadow;
    }

    private boolean czyDodacSasiada(int x, int y, int wartosc){
        return (!sprawdzonePozycje[x][y] && tablicaWartosci[x][y]==wartosc);
    }

    @Nullable
    private Kafelek znajdzKafelek(int x, int y){
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i = 0; i < ileKafelkow; i++) {
            Kafelek pKafelek = (Kafelek) gridLayout.getChildAt(i);
            if ((pKafelek.getPosInGrid()[0]==x) && (pKafelek.getPosInGrid()[1]==y)) return pKafelek;
        }
        return null;
    }

    private void czyscSprawdzonePozycje() {
        sprawdzonePozycje=new boolean[rozmiarPola+2][rozmiarPola+2];
    }

    private void ustawKolor(TextView kafelek, int pkt){
        kafelek.setBackground(getResources().getDrawable(podajKolor(pkt+1)));
    }

    private void czyscKafeki(Set<Kafelek> aLista){
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();

        for(Kafelek pKafelek:aLista){
            pKafelek.setBackground(getResources().getDrawable(R.drawable.bg_round));
            int pX=pKafelek.getPosInGrid()[0];
            int pY=pKafelek.getPosInGrid()[1];
            for (int i=0; i<ileKafelkow;i++){
                if (((Kafelek)gridLayout.getChildAt(i)).getPosInGrid()[0]==pX &&((Kafelek)gridLayout.getChildAt(i)).getPosInGrid()[1]==pY) {
                    ((Kafelek)gridLayout.getChildAt(i)).setText("   ");
                    tablicaWartosci[pX][pY]=0;
                    break;
                }
            }
        }
    }

    private void ustawKafelek(Kafelek aKafelek, int aWartosc){
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];
        tablicaWartosci[pX][pY]=aWartosc;
        if (aWartosc==0)aKafelek.setText("   ");
        else aKafelek.setText(String.valueOf(aWartosc));
        ustawKolor(aKafelek,aWartosc);
    }

    private void dodajPKT(int nowePKT){
        punkty+=nowePKT;
        licznikPKT.setText(String.valueOf(punkty));
    }

    private void sprawdzicDostepneBonusy() {
        for (Bonus pBonus:listaBonusow){
            if (pktNaBonus>=pBonus.getIlePKT()) pBonus.getImg().setImageDrawable(getResources().getDrawable(pBonus.getIdImgOff()));
            else pBonus.getImg().setImageDrawable(getResources().getDrawable(pBonus.getIdImgDisable()));
        }
    }

    private void ustawProgresBary(){
        for(Bonus bonus:listaBonusow){
            int progres=(pktNaBonus*100)/bonus.getIlePKT();
            bonus.getProgress().setProgress(progres);
            bonus.getKrotnosc().setText(progres > 99 ? String.valueOf((int) (progres / 100)) : null);
        }
    }

    private void animujIkonyBonusow(int pkt){
        int pktPrzed=pktNaBonus-pkt;
        for (Bonus pBonus:listaBonusow){
            if (pBonus.getIlePKT()<=pktNaBonus && pBonus.getIlePKT()>pktPrzed) {
                Animation animZoom = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom);
                pBonus.getImg().startAnimation(animZoom);
            }
        }
    }

    private void ustawIkoneBonusa(Bonus.Typ typ){
        sprawdzicDostepneBonusy();
        if (typ!=null) {
            for(Bonus bonus:listaBonusow) {
                if (bonus.getTyp()==typ) bonus.getImg().setImageDrawable(getResources().getDrawable(bonus.getIdImgOn()));
            }
        }
    }

    private boolean czyKoniecGry() {
        if (pktNaBonus > Stale.PKT_BONUS_1) return false;

        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i = 0; i < ileKafelkow; i++) {
            Kafelek pKafelek = (Kafelek) gridLayout.getChildAt(i);
            if (pKafelek.getText().length() == 3) return false;
        }
        return true;
    }

    private void pokazKoniec(){
        LinearLayout lay=(LinearLayout) findViewById(R.id.lay_gra_koniec);
        ImageView end=new ImageView(this);
        end.setImageResource(R.mipmap.end);
        lay.addView(end);
    }

    private void zapiszWynik(int pkt){
        DAO dao=new DAO(getApplicationContext());
        //dao.dodajWynik(pkt,poziom);
        if (pkt>Stale.GRANICA_6) dao.ustawDostepny6();
    }

    private void udostepnijWynik(final int pkt){
        LinearLayout lay=(LinearLayout) findViewById(R.id.lay_gra_koniec);
        ImageView share=new ImageView(this);
        if (pkt >= Stale.GRANICA_UDOSTEPNIENIA_ARCADE) {
            share.setImageResource(R.mipmap.share_on);
            share.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    wyslijWynik(pkt);
                    //udostepnijFB(pkt);
                    return true;
                }
            });
        } else {
            share.setImageResource(R.mipmap.share_off);
            share.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    Toast.makeText(getApplicationContext(), "Need "+ Stale.GRANICA_UDOSTEPNIENIA_ARCADE +" points", Toast.LENGTH_LONG).show();
                    return false;
                }
            });
        }
        lay.addView(share);
    }

    private void wyslijWynik(int pkt){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},Stale.ZEZWOLENIE);
            } else {
                ActivityCompat.requestPermissions(this,  new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Stale.ZEZWOLENIE);
            }
        } else {
            udostepnij(pkt);
        }
    }


    private void udostepnij(int pkt){ // udostepnianie ogolne
        int id_bmp_wynikow;
        if (poziom==5) id_bmp_wynikow=R.mipmap.wynik_5;
        else id_bmp_wynikow=R.mipmap.wynik_6;

        Bitmap icon = BitmapFactory.decodeResource(getApplicationContext().getResources(), id_bmp_wynikow);

        Bitmap workingBitmap = Bitmap.createBitmap(icon);
        Bitmap mutableBitmap = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(mutableBitmap);
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setAntiAlias(true);
        paint.setTextSize(canvas.getHeight()/10);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(String.valueOf(pkt), (canvas.getWidth() / 2f) , (canvas.getHeight() / 1.53f), paint);

        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("image/jpeg");

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "Game score");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        OutputStream outstream;
        try {
            outstream = getContentResolver().openOutputStream(uri);
            mutableBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outstream);
            outstream.close();
        } catch (Exception e) {
            System.err.println(e.toString());
        }

        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.putExtra(Intent.EXTRA_TEXT, "New score: "+ pkt+" points");
        startActivity(Intent.createChooser(share, "Share Image"));
    }

    private void dodajPrzyciskiRestartWyjscie(){
        RelativeLayout lay = (RelativeLayout) findViewById(R.id.lay);

        ImageView exit= new ImageView(getApplicationContext());
        exit.setImageDrawable(getResources().getDrawable(R.mipmap.exit));
        exit.setTag("tmp");
        RelativeLayout.LayoutParams paramsExit= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsExit.setMargins(20,20,20,20);
        paramsExit.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        lay.addView(exit,paramsExit);

        final ImageView restart= new ImageView(getApplicationContext());
        restart.setImageDrawable(getResources().getDrawable(R.mipmap.restart));
        restart.setTag("tmp");
        RelativeLayout.LayoutParams paramsRestart= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsRestart.setMargins(20,20,20,20);
        paramsRestart.addRule(RelativeLayout.ALIGN_PARENT_END);
        paramsRestart.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        lay.addView(restart,paramsRestart);

        exit.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                wyjscie();
                return true;
            }
        });

        restart.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                nowaGra();
                return true;
            }
        });

    }

    private void wyjscie(){
        finish();
    }

    private void schowajPrzyciski(){
        LinearLayout layLin = (LinearLayout) findViewById(R.id.lay_gra_koniec);
        layLin.removeAllViews();

        RelativeLayout lay = (RelativeLayout) findViewById(R.id.lay);
        List <View> listaDoUsuniecia=new ArrayList<>();
        int ile=lay.getChildCount();
        for (int i=0;i<ile;i++){
            View view=lay.getChildAt(i);
            if (view instanceof ImageView){
                if (view.getTag().equals("tmp")) listaDoUsuniecia.add(view);
            }
        }
        for(View view:listaDoUsuniecia) {
            lay.removeView(view);
        }
    }

    private void udostepnijFB(int punkty) {
        //FacebookSdk.sdkInitialize(this);
        if (!ShareDialog.canShow(ShareLinkContent.class)) return;
        FacebookSdk.setApplicationId(getString(R.string.facebook_app_id));
        //CallbackManager callbackManager = CallbackManager.Factory.create();
        //ShareDialog shareDialog = new ShareDialog(this);
        //ShareLinkContent linkContent = new ShareLinkContent.Builder()
                        //.setContentTitle("Sigma new score: " + punkty)
                        //.setContentDescription("desc")
                        //.setImageUrl(Uri.parse("android.resource:tridoo.sigma" + idBmp))
//                        .setContentUrl(Uri.parse(getString(R.string.link))).build();
        //shareDialog.show(linkContent);

        ShareOpenGraphObject object = new ShareOpenGraphObject.Builder()
                .putString("og:type", "books.book")
                .putString("og:title", "A Game of Thrones")
                .putString("og:description", "In the frozen wastes to the north of Winterfell, sinister and supernatural forces are mustering.")
                .putString("books:isbn", "0-553-57340-3")
                .build();

        SharePhoto photo = new SharePhoto.Builder()
                .setBitmap(BitmapFactory.decodeResource(getApplicationContext().getResources(), R.mipmap.wynik_5))
                .setUserGenerated(true)
                .build();

        ShareOpenGraphAction action = new ShareOpenGraphAction.Builder()
                .setActionType("books.reads")
                .putObject("book", object)
                .putPhoto("image", photo)
                .build();


        ShareOpenGraphContent content = new ShareOpenGraphContent.Builder()
                .setPreviewPropertyName("fitness:course")
                .setAction(action)
                .build();

        ShareDialog.show(this, content);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,  String permissions[], int[] grantResults) {
        switch (requestCode) {
            case Stale.ZEZWOLENIE: {
                if (grantResults.length > 0  && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    udostepnij(punkty);
                } else {
                    // brak uprawnien
                }
                return;
            }
        }
    }
}