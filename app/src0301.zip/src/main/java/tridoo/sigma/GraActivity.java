package tridoo.sigma;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.Gravity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.FacebookSdk;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareOpenGraphAction;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.ShareOpenGraphObject;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.widget.ShareDialog;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;
import java.util.Set;

abstract class GraActivity extends Activity {
    int maxWynikGlobalny;
    String plikFTP;
    String email;
    String xywa;

    int maxLiczba;
    int rozmiarPola;
    int tablicaWartosci[][];
    boolean sprawdzonePozycje[][], czyTimer;
    int punkty;
    List<Integer> paletaKolorow;
    TextView licznikPKT;
    TextView zrodlo;

    Context context;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gra);
        context=getApplicationContext();
        wypelnijNaglowek();
        licznikPKT=(TextView)findViewById(R.id.tv_pkt);
        zrodlo= (TextView)findViewById(R.id.tv_zrodlo);

        rozmiarPola=getIntent().getIntExtra("poziom",1);
        paletaKolorow = Utils.podajPaleteTel(rozmiarPola);
        dodajPusteKafelki();
        pobierzDaneFtp(); //zawiera update xywy
    }

    @Override
    protected void onResume() {
        super.onResume();
        //uruchomReklamy();
    }

    @Override
    public void onBackPressed() {
        if(punkty==0 || czyKoniecGry()) {
            super.onBackPressed();
            return;
        }
        stoperPause();

        Dialog dialog;
        final String[] items = {"Save Score"};
        final boolean[] selectedItems={true};

        final ArrayList<Integer> itemsSelected = new ArrayList<>();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("End the game?");
        builder.setMultiChoiceItems(items, selectedItems,
                new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedItemId,
                                        boolean isSelected) {
                        if (isSelected) {
                            itemsSelected.add(selectedItemId);
                        } else if (itemsSelected.contains(selectedItemId)) {
                            itemsSelected.remove(Integer.valueOf(selectedItemId));
                        }
                    }
                })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        if (((AlertDialog) dialog).getListView().getCheckedItemPositions().get(0)) {
                            zapiszWynik(punkty,czyTimer);
                        }
                        GraActivity.super.onBackPressed();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                stoperUnpause();
                            }
                        }
                );
        dialog = builder.create();
        dialog.show();
    }

    private void uruchomReklamy()    {
        AdView mAdView = (AdView) findViewById(R.id.banerGra);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    protected void wypelnijNaglowek(){};//tylko w timer

    protected void nowaGra(){
        punkty=0;
        maxLiczba=1;
        tablicaWartosci=new int[rozmiarPola+2][rozmiarPola+2];
        sprawdzonePozycje=new boolean[rozmiarPola+2][rozmiarPola+2];
        ustawZrodlo(1);
        dodajPierwszeKafeleki();
        licznikPKT.setText(String.valueOf(0));
    }

    private int podajKolor(int pkt){
        int rozmiar=paletaKolorow.size();
        if (pkt>=rozmiar) return paletaKolorow.get(rozmiar-1);
        else return paletaKolorow.get(pkt);
    }

    private void dodajPusteKafelki(){ //todo kontroler ekranu
        final GridLayout gridLayout=(GridLayout)findViewById(R.id.gridLayout);
        gridLayout.removeAllViews();
        gridLayout.setColumnCount(rozmiarPola);
        gridLayout.setRowCount(rozmiarPola);
        for (int i = 0; i < rozmiarPola; i++) {
            for (int j = 0; j < rozmiarPola; j++) {

                Kafelek textView = new Kafelek(this);
                textView.setBackground(getResources().getDrawable(R.drawable.bg_round));
                textView.setText("   ");
                textView.setTextSize(getResources().getDimension(R.dimen.rozmiar_normal));
                textView.setGravity(Gravity.CENTER);
                textView.setPosInGrid(j+1, i+1);
                dodajLiseneryKafelka(textView);

                int marginesKafelka=getResources().getDimensionPixelSize(R.dimen.margines_kafelka);
                GridLayout.LayoutParams gridParam = new GridLayout.LayoutParams();
                gridParam.setMargins(marginesKafelka, marginesKafelka, marginesKafelka, marginesKafelka);
                gridParam.setGravity(Gravity.FILL);
                gridLayout.addView(textView, gridParam);
            }
        }

        gridLayout.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        int marginesKafelka = getResources().getDimensionPixelSize(R.dimen.margines_kafelka);
                        int szerokosc = (int) ((gridLayout.getWidth() - 2 * rozmiarPola * marginesKafelka));
                        int wysokosc = (int) ((gridLayout.getHeight() - 2 * rozmiarPola * marginesKafelka));
                        for (int i = 0; i < rozmiarPola * rozmiarPola; i++) {
                            ((Kafelek) gridLayout.getChildAt(i)).setWidth(szerokosc / rozmiarPola);
                            ((Kafelek) gridLayout.getChildAt(i)).setHeight(wysokosc / rozmiarPola);
                        }
                        gridLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }
                });
    }

    abstract protected void dodajLiseneryKafelka(Kafelek kafelek);

    protected void ustawZrodlo(int liczba){
        zrodlo.setText(String.valueOf(liczba));
        ustawKolor(zrodlo,liczba);
    }

    private void dodajPierwszeKafeleki(){ //todo kontroler ekranu
        Random rnd=new Random();
        int x, y, ile=0;
        Kafelek kafelek;

        do{
            x=rnd.nextInt(rozmiarPola)+1;
            y=rnd.nextInt(rozmiarPola)+1;
            if(tablicaWartosci[x][y]==1) continue;
            kafelek=znajdzKafelek(x,y);
            tablicaWartosci[x][y]=1;
            if(podajListeOdpowiednichSasiadow(kafelek).size()>1){
                tablicaWartosci[x][y]=0;
                czyscSprawdzonePozycje();
                continue;
            }
            ustawKafelek(kafelek,1);
            ile++;
            czyscSprawdzonePozycje();
        }while(ile<Stale.ILE_NA_STARCIE);
    }

    protected void sprawdzKafelek(Kafelek kafelek, String aWartosc) {
        boolean czyBylyZmiany = false;
        int pWartosc = Integer.valueOf(aWartosc);
        int x=kafelek.getPosInGrid()[0];
        int y=kafelek.getPosInGrid()[1];
        tablicaWartosci[x][y] = pWartosc;
        ustawKafelek(kafelek,pWartosc);
        Set<Kafelek> pListaOdpowiednichSasiadow = podajListeOdpowiednichSasiadow(kafelek);

        if (pListaOdpowiednichSasiadow.size() > 2) {
            if (pWartosc == maxLiczba) maxLiczba++;
            czyscKafeki(pListaOdpowiednichSasiadow);
            tablicaWartosci[x][y] = pWartosc + 1;
            ustawKafelek(kafelek,pWartosc+1);
            int pkt = Utils.ilePunktowDodac(pWartosc, pListaOdpowiednichSasiadow.size());
            dodajPKT(pkt);
            czyBylyZmiany = true;
            operacjeDodatkowePunktow(pkt);
            dodajCzas(pWartosc);
        }
        if (czyKoniecGry()) {
            koniecGry();
        } else {
            czyscSprawdzonePozycje();
            if (czyBylyZmiany) sprawdzKafelek(kafelek, String.valueOf(pWartosc + 1));
            operacjaDodatkoweBonusow();
        }
    }

    protected void operacjeDodatkowePunktow(int pkt){    }

    protected void operacjaDodatkoweBonusow(){}

    protected  void dodajCzas(int ile){}

    abstract int podajGraniceUdostepniania();

    protected void koniecGry(){
        pokazKoniec();
        zapiszWynik(punkty,czyTimer); //rowniez globalny
        udostepnijWynik(punkty);
        dodajPrzyciskiRestartWyjscie();
    }

    private Set<Kafelek> podajListeOdpowiednichSasiadow(Kafelek aKafelek){
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];
        int pWartosc=tablicaWartosci[pX][pY];

        sprawdzonePozycje[pX][pY]=true;
        Set<Kafelek> listaDoZamiany=new HashSet<>();
        listaDoZamiany.add(aKafelek);
        List<Kafelek> listaDoSprawdzenia=new ArrayList<>();
        List<Kafelek> tmp=podajFiltrowanaListeSasiadow(aKafelek, pWartosc);
        listaDoZamiany.addAll(tmp);
        listaDoSprawdzenia.addAll(tmp);

        ListIterator<Kafelek> iterator = listaDoSprawdzenia.listIterator();
        while (iterator.hasNext()) {
            Kafelek pKafelek = iterator.next();
            tmp=podajFiltrowanaListeSasiadow(pKafelek, pWartosc);
            if (!tmp.isEmpty()){
                listaDoZamiany.addAll(tmp);
                for (Kafelek aSasiad: tmp){
                    iterator.add(aSasiad);
                    iterator.previous();
                }
            }
        }
        return listaDoZamiany;
    }

    private List<Kafelek> podajFiltrowanaListeSasiadow(Kafelek aKafelek, int aWartosc){
        List<Kafelek> pListaSasiadow=new ArrayList<>();
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];

        for (Point wspolrzedna : Stale.wspolrzedneSasiadow) {
            if (czyDodacSasiada(pX-wspolrzedna.x, pY-wspolrzedna.y, aWartosc))
                pListaSasiadow.add(znajdzKafelek(pX-wspolrzedna.x, pY-wspolrzedna.y));
        }
        sprawdzonePozycje[pX][pY]=true;
        return pListaSasiadow;
    }

    private boolean czyDodacSasiada(int x, int y, int wartosc){
        return (!sprawdzonePozycje[x][y] && tablicaWartosci[x][y]==wartosc);
    }

    @Nullable
    private Kafelek znajdzKafelek(int x, int y){
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i = 0; i < ileKafelkow; i++) {
            Kafelek pKafelek = (Kafelek) gridLayout.getChildAt(i);
            if ((pKafelek.getPosInGrid()[0]==x) && (pKafelek.getPosInGrid()[1]==y)) return pKafelek;
        }
        return null;
    }

    private void czyscSprawdzonePozycje() {
        sprawdzonePozycje=new boolean[rozmiarPola+2][rozmiarPola+2];
    }

    protected void ustawKolor(TextView kafelek, int pkt){ //todo kontroler ekranu
        kafelek.setBackground(getResources().getDrawable(podajKolor(pkt+1)));
    }

    protected void czyscKafeki(Set<Kafelek> aLista){ //todo kontroler ekranu
        for(Kafelek pKafelek:aLista){
            ustawKafelek(pKafelek,0);
        }
    }

    private void czyscWszystkieKafelki(){ //todo kontroler ekranu
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i=0; i<ileKafelkow;i++){
            ustawKafelek((Kafelek)gridLayout.getChildAt(i),0);
        }
    }

    protected void ustawKafelek(Kafelek aKafelek, int aWartosc){ //todo kontroler ekranu
        int pX=aKafelek.getPosInGrid()[0];
        int pY=aKafelek.getPosInGrid()[1];
        tablicaWartosci[pX][pY]=aWartosc;
        if (aWartosc==0)aKafelek.setText("   ");
        else aKafelek.setText(String.valueOf(aWartosc));
        ustawKolor(aKafelek,aWartosc);
    }

    private void dodajPKT(int nowePKT){
        punkty+=nowePKT;
        licznikPKT.setText(String.valueOf(punkty));
    }

    protected boolean czyKoniecGry() {
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        int ileKafelkow = gridLayout.getChildCount();
        for (int i = 0; i < ileKafelkow; i++) {
            Kafelek pKafelek = (Kafelek) gridLayout.getChildAt(i);
            if (pKafelek.getText().length() == 3) return false;
        }
        return true;
    }

    private void pokazKoniec(){ //todo kontroler ekranu
        LinearLayout lay=(LinearLayout) findViewById(R.id.lay_gra_koniec);
        ImageView end=new ImageView(this);
        end.setImageResource(R.mipmap.end);
        lay.addView(end);
    }

    private void zapiszWynik(int pkt, boolean isCzyTimer){
        DAO dao=new DAO(context);
        dao.dodajWynik(pkt,rozmiarPola,isCzyTimer);
        if (pkt>Stale.GRANICA_6) dao.ustawDostepny6();
        if (pkt>maxWynikGlobalny)  {
            try {
                String progres=new FtpTask(this).execute(podajNazwePlikuFTP(),podajEmail(),podajXywe(),String.valueOf(pkt)).get();
                //progres tylko na czekanie przed zamknieciem
            } catch (Exception e) {
                e.printStackTrace();
            }
            maxWynikGlobalny=pkt;
        }
    }

    private void udostepnijWynik(final int pkt){
        LinearLayout lay=(LinearLayout) findViewById(R.id.lay_gra_koniec);
        ImageView share=new ImageView(this);
        if (pkt >= podajGraniceUdostepniania()) {
            share.setImageResource(R.mipmap.share_on);
            share.setOnClickListener((new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    wyslijWynik(pkt);
                    //udostepnijFB(pkt);
                }
            }));         share.setImageResource(R.mipmap.share_off);
            share.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "Need "+ podajGraniceUdostepniania() +" points", Toast.LENGTH_LONG).show();
                }
            });
        }
        lay.addView(share);
    }

    private void wyslijWynik(int pkt){//todo refaktor nazw
        if (ContextCompat.checkSelfPermission(context,  Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            udostepnij(pkt);
            return;
        }

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            Toast.makeText(context, "NEED PERMISSION", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Stale.ZEZWOLENIE);
        }

    }

    private void udostepnij(int pkt){ // udostepnianie ogolne
        int id_bmp_wynikow;
        if (rozmiarPola==5) id_bmp_wynikow=R.mipmap.wynik_5;
        else id_bmp_wynikow=R.mipmap.wynik_6;

        Bitmap icon = BitmapFactory.decodeResource(getApplicationContext().getResources(), id_bmp_wynikow);

        Bitmap workingBitmap = Bitmap.createBitmap(icon);
        Bitmap mutableBitmap = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(mutableBitmap);
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setAntiAlias(true);
        paint.setTextSize(canvas.getHeight()/10);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(String.valueOf(pkt), (canvas.getWidth() / 2f) , (canvas.getHeight() / 1.53f), paint);

        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("image/jpeg");

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "Game score");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        OutputStream outstream;
        try {
            outstream = getContentResolver().openOutputStream(uri);
            mutableBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outstream);
            outstream.close();
        } catch (Exception e) {
            System.err.println(e.toString());
        }

        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.putExtra(Intent.EXTRA_TEXT, "New score: "+ pkt+" points");
        startActivity(Intent.createChooser(share, "Share Image"));
    }

    private void dodajPrzyciskiRestartWyjscie(){ //todo kontroler ekranu
        RelativeLayout lay = (RelativeLayout) findViewById(R.id.lay);

        ImageView exit= new ImageView(getApplicationContext());
        exit.setImageDrawable(getResources().getDrawable(R.mipmap.exit));
        exit.setTag("tmp");
        RelativeLayout.LayoutParams paramsExit= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsExit.setMargins(20,20,20,20);
        paramsExit.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        lay.addView(exit,paramsExit);

        final ImageView restart= new ImageView(getApplicationContext());
        restart.setImageDrawable(getResources().getDrawable(R.mipmap.restart));
        restart.setTag("tmp");
        RelativeLayout.LayoutParams paramsRestart= new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        paramsRestart.setMargins(20,20,20,20);
        paramsRestart.addRule(RelativeLayout.ALIGN_PARENT_END);
        paramsRestart.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        lay.addView(restart,paramsRestart);

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wyjscie();
            }
        });

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                schowajPrzyciski();
                czyscWszystkieKafelki();
                nowaGra();
            }
        });

    }

    private void wyjscie(){
        finish();
    }

    private void schowajPrzyciski(){ //todo kontroler ekranu
        LinearLayout layLin = (LinearLayout) findViewById(R.id.lay_gra_koniec);
        layLin.removeAllViews();

        RelativeLayout lay = (RelativeLayout) findViewById(R.id.lay);
        List <View> listaDoUsuniecia=new ArrayList<>();
        int ile=lay.getChildCount();
        for (int i=0;i<ile;i++){
            View view=lay.getChildAt(i);
            if (view instanceof ImageView){
                if (view.getTag().equals("tmp")) listaDoUsuniecia.add(view);
            }
        }
        for(View view:listaDoUsuniecia) {
            lay.removeView(view);
        }
    }

    private void udostepnijFB(int punkty) {
        //FacebookSdk.sdkInitialize(this);
        if (!ShareDialog.canShow(ShareLinkContent.class)) return;
        FacebookSdk.setApplicationId(getString(R.string.facebook_app_id));
        //CallbackManager callbackManager = CallbackManager.Factory.create();
        //ShareDialog shareDialog = new ShareDialog(this);
        //ShareLinkContent linkContent = new ShareLinkContent.Builder()
                        //.setContentTitle("Sigma new score: " + punkty)
                        //.setContentDescription("desc")
                        //.setImageUrl(Uri.parse("android.resource:tridoo.sigma" + idBmp))
//                        .setContentUrl(Uri.parse(getString(R.string.link))).build();
        //shareDialog.show(linkContent);

        ShareOpenGraphObject object = new ShareOpenGraphObject.Builder()
                .putString("og:type", "books.book")
                .putString("og:title", "A Game of Thrones")
                .putString("og:description", "In the frozen wastes to the north of Winterfell, sinister and supernatural forces are mustering.")
                .putString("books:isbn", "0-553-57340-3")
                .build();

        SharePhoto photo = new SharePhoto.Builder()
                .setBitmap(BitmapFactory.decodeResource(getApplicationContext().getResources(), R.mipmap.wynik_5))
                .setUserGenerated(true)
                .build();

        ShareOpenGraphAction action = new ShareOpenGraphAction.Builder()
                .setActionType("books.reads")
                .putObject("book", object)
                .putPhoto("image", photo)
                .build();


        ShareOpenGraphContent content = new ShareOpenGraphContent.Builder()
                .setPreviewPropertyName("fitness:course")
                .setAction(action)
                .build();

        ShareDialog.show(this, content);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,  String permissions[], int[] grantResults) {
        switch (requestCode) {
            case Stale.ZEZWOLENIE: {
                if (grantResults.length > 0  && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    udostepnij(punkty);
                } else {
                    // brak uprawnien
                }
                return;
            }
        }
    }


    public void setMaxWynikGlobalny(int maxWynikGlobalny) {
        this.maxWynikGlobalny = maxWynikGlobalny;
    }

    public void pobierzDaneFtp(){ //wynik ustawiany w ftp onPostExecute
        plikFTP=podajNazwePlikuFTP();
        xywa=podajXywe();
        email=podajEmail();
        new FtpTask(this).execute(plikFTP,podajEmail(),xywa);
    }

    private String podajNazwePlikuFTP() {
        if (plikFTP!=null) return plikFTP;
        String nazwa = "wyniki_";
        int poziom = getIntent().getIntExtra("poziom", 1);
        boolean czyTimer = getIntent().getBooleanExtra("czyTimer", false);
        nazwa += poziom == 5 ? "5_" : "6_";
        nazwa += czyTimer ? "t" : "a";
        return nazwa+=".txt";
    }

    private String podajXywe(){
        if (xywa!=null) return xywa;
        String nick=getIntent().getStringExtra("xywa");
        if (nick==null) nick = getIntent().getStringExtra("nowaXywa");
        return nick;
    }

    private String podajEmail(){
        if (email!=null) return email;
        return getIntent().getStringExtra("email");
    }

    protected void stoperPause(){
        //tylko dla timera
    }

    protected void stoperUnpause(){
        //tylko dla timera
    }

}